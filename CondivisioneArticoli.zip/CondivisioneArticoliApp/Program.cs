using CondivisioneArticoliApp.Forms;

namespace CondivisioneArticoliApp;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
