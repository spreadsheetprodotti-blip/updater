using System.Text.Json;
using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class AppCacheService
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    public string CacheFolder { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "CondivisioneArticoliApp");

    private string CachePath => Path.Combine(CacheFolder, "cache.json");

    public void Save(AppData data)
    {
        Directory.CreateDirectory(CacheFolder);
        var snapshot = CacheSnapshot.From(data);
        File.WriteAllText(CachePath, JsonSerializer.Serialize(snapshot, JsonOptions));
    }

    public bool TryLoad(AppData data)
    {
        if (!File.Exists(CachePath))
            return false;

        var json = File.ReadAllText(CachePath);
        var snapshot = JsonSerializer.Deserialize<CacheSnapshot>(json, JsonOptions);
        if (snapshot is null)
            return false;

        data.FileRows.Clear();
        data.FileRows.AddRange(snapshot.FileRows);
        data.WebRows.Clear();
        data.WebRows.AddRange(snapshot.WebRows);
        data.Suppliers.Clear();
        data.Suppliers.AddRange(snapshot.Suppliers);
        data.Categories.Clear();
        data.Categories.AddRange(snapshot.Categories);
        data.Barcodes.Clear();
        data.Barcodes.AddRange(snapshot.Barcodes);
        data.LearningItems.Clear();
        data.LearningItems.AddRange(snapshot.LearningItems);

        data.LearningByDescription.Clear();
        data.LearningByCode.Clear();
        data.LearningSuggestions.Clear();

        foreach (var item in data.LearningItems)
        {
            if (!string.IsNullOrWhiteSpace(item.Input) && !string.IsNullOrWhiteSpace(item.Output))
            {
                data.LearningByDescription[item.Input] = item.Output;
                if (!data.LearningSuggestions.TryGetValue(item.Input, out var suggestions))
                {
                    suggestions = [];
                    data.LearningSuggestions[item.Input] = suggestions;
                }

                if (!suggestions.Contains(item.Output, StringComparer.OrdinalIgnoreCase))
                    suggestions.Add(item.Output);
            }

            if (!string.IsNullOrWhiteSpace(item.Code) && !data.LearningByCode.ContainsKey(item.Code))
                data.LearningByCode[item.Code] = item.Output;
        }

        return true;
    }

    public void Clear()
    {
        if (File.Exists(CachePath))
            File.Delete(CachePath);
    }

    private sealed class CacheSnapshot
    {
        public List<ArticleRow> FileRows { get; set; } = [];
        public List<ProductRow> WebRows { get; set; } = [];
        public List<SupplierRow> Suppliers { get; set; } = [];
        public List<string[]> Categories { get; set; } = [];
        public List<string[]> Barcodes { get; set; } = [];
        public List<LearningItem> LearningItems { get; set; } = [];

        public static CacheSnapshot From(AppData data) => new()
        {
            FileRows = data.FileRows.ToList(),
            WebRows = data.WebRows.ToList(),
            Suppliers = data.Suppliers.ToList(),
            Categories = data.Categories.ToList(),
            Barcodes = data.Barcodes.ToList(),
            LearningItems = data.LearningItems
                .Concat(data.LearningByDescription.Select(kv => new LearningItem { Input = kv.Key, Output = kv.Value }))
                .GroupBy(item => $"{item.Input}|{item.Output}|{item.Code}", StringComparer.OrdinalIgnoreCase)
                .Select(group => group.First())
                .ToList()
        };
    }
}
