using System.Diagnostics;
using System.Globalization;
using System.Net.Http;
using System.Reflection;

namespace CondivisioneArticoliApp.Services;

public sealed class UpdateService
{
    private const string VersionUrl = "https://raw.githubusercontent.com/spreadsheetprodotti-blip/updater/refs/heads/main/versione.txt";
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(15) };

    public async Task<AvailableUpdate?> CheckAsync(CancellationToken cancellationToken = default)
    {
        var text = (await _http.GetStringAsync(VersionUrl, cancellationToken)).Trim();
        var parts = text.Split('|', StringSplitOptions.TrimEntries);
        if (parts.Length < 2)
            throw new InvalidOperationException("Formato versione online non valido.");

        var online = ParseVersion(parts[0]);
        var local = ParseVersion(AppVersion);
        return online > local
            ? new AvailableUpdate(parts[0], parts[1])
            : null;
    }

    public async Task<string> DownloadAsync(AvailableUpdate update, CancellationToken cancellationToken = default)
    {
        var extension = Path.GetExtension(new Uri(update.DownloadUrl).AbsolutePath);
        if (string.IsNullOrWhiteSpace(extension))
            extension = ".bin";

        var folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "CondivisioneArticoliApp",
            "updates");
        Directory.CreateDirectory(folder);

        var file = Path.Combine(folder, $"CondivisioneArticoliApp-{update.Version}{extension}");
        using var response = await _http.GetAsync(update.DownloadUrl, cancellationToken);
        response.EnsureSuccessStatusCode();

        await using var input = await response.Content.ReadAsStreamAsync(cancellationToken);
        await using var output = File.Create(file);
        await input.CopyToAsync(output, cancellationToken);
        return file;
    }

    public static string AppVersion =>
        Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion
        ?? Assembly.GetExecutingAssembly().GetName().Version?.ToString()
        ?? "0.1.0";

    private static double ParseVersion(string value)
    {
        value = value.Trim().Replace(',', '.');
        return double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var parsed)
            ? parsed
            : 0;
    }
}

public sealed record AvailableUpdate(string Version, string DownloadUrl);
