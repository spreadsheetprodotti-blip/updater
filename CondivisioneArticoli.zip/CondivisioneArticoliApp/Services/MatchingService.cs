using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class MatchingService
{
    private readonly TextNormalizer _normalizer;
    private readonly Dictionary<string, ProductRow> _barcodeIndex = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, List<ProductRow>> _wordIndex = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _usedProducts = new(StringComparer.OrdinalIgnoreCase);

    public MatchingService(TextNormalizer normalizer)
    {
        _normalizer = normalizer;
    }

    public void BuildIndex(IEnumerable<ProductRow> products)
    {
        _barcodeIndex.Clear();
        _wordIndex.Clear();

        foreach (var product in products)
        {
            if (!string.IsNullOrWhiteSpace(product.Barcode) && !_barcodeIndex.ContainsKey(product.Barcode))
                _barcodeIndex[product.Barcode] = product;

            foreach (var word in _normalizer.GetWords(product.Name))
            {
                if (!_wordIndex.TryGetValue(word, out var list))
                {
                    list = [];
                    _wordIndex[word] = list;
                }

                list.Add(product);
            }
        }
    }

    public void SetUsedProducts(IEnumerable<string> usedProducts)
    {
        _usedProducts.Clear();
        foreach (var product in usedProducts.Where(value => !string.IsNullOrWhiteSpace(value)))
            _usedProducts.Add(product);
    }

    public ProductRow? FindBest(string description, string barcode)
    {
        if (!string.IsNullOrWhiteSpace(barcode) && _barcodeIndex.TryGetValue(barcode, out var byBarcode))
            return byBarcode;

        return FindTop(description, 1).FirstOrDefault();
    }

    public List<ProductRow> FindTop(string description, int max = 14)
    {
        var inputWords = _normalizer.GetWords(description);
        if (inputWords.Length == 0)
            return [];

        var candidates = new Dictionary<ProductRow, double>();
        foreach (var word in _normalizer.ExpandSynonyms(inputWords))
        {
            if (_wordIndex.TryGetValue(word, out var exact))
            {
                foreach (var product in exact)
                    candidates[product] = candidates.GetValueOrDefault(product) + 2;
            }

            if (word.Length >= 5)
            {
                foreach (var indexed in _wordIndex.Keys.Where(k => k.StartsWith(word, StringComparison.OrdinalIgnoreCase)))
                {
                    foreach (var product in _wordIndex[indexed])
                        candidates[product] = candidates.GetValueOrDefault(product) + 1.25;
                }
            }
        }

        foreach (var product in candidates.Keys.ToList())
        {
            var productWords = _normalizer.GetWords(product.Name);
            candidates[product] += NumberBonus(inputWords, productWords);
            if (inputWords.FirstOrDefault() == productWords.FirstOrDefault())
                candidates[product] += 6;
            if (_usedProducts.Contains(product.Name))
                candidates[product] -= 3;
        }

        return candidates
            .OrderByDescending(kv => kv.Value)
            .Take(max)
            .Select(kv => kv.Key)
            .ToList();
    }

    private static double NumberBonus(string[] inputWords, string[] productWords)
    {
        var inputNumbers = inputWords.Where(TextNormalizer.ContainsDigit)
            .Select(TextNormalizer.NormalizeNumber)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (inputNumbers.Count == 0)
            return 0;

        var productNumbers = productWords.Where(TextNormalizer.ContainsDigit)
            .Select(TextNormalizer.NormalizeNumber)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var bonus = 0d;
        foreach (var input in inputNumbers)
            bonus += productNumbers.Contains(input) ? 6 : -3;

        return bonus;
    }

    public static bool IsSafeMatch(TextNormalizer normalizer, string inputDescription, string match)
    {
        var distance = LearningService.LevenshteinDistance(normalizer.Normalize(inputDescription), normalizer.Normalize(match));
        var maxLen = Math.Max(inputDescription.Length, match.Length);
        if (maxLen == 0)
            return false;

        var threshold = maxLen switch
        {
            <= 10 => 0.15,
            <= 20 => 0.22,
            <= 40 => 0.28,
            _ => 0.35
        };

        if (NumberBonus(normalizer.GetWords(inputDescription), normalizer.GetWords(match)) > 0)
            threshold += 0.05;

        return distance / (double)maxLen <= threshold;
    }
}
