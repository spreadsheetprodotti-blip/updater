using System.Net.Http;
using System.Text;

namespace CondivisioneArticoliApp.Services;

public sealed class CsvService
{
    private readonly HttpClient _http = new();

    public async Task<List<string[]>> DownloadCsvAsync(string url, CancellationToken cancellationToken = default) =>
        await DownloadCsvAsync(url, ',', cancellationToken);

    public async Task<List<string[]>> DownloadCsvAsync(string url, char separator, CancellationToken cancellationToken = default)
    {
        var csv = await _http.GetStringAsync(url, cancellationToken);
        return Parse(csv, separator);
    }

    public static List<string[]> Parse(string csv) => Parse(csv, ',');

    public static List<string[]> Parse(string csv, char separator)
    {
        var rows = new List<string[]>();
        using var reader = new StringReader(csv);
        while (reader.ReadLine() is { } line)
            rows.Add(ParseLine(line, separator).ToArray());
        return rows;
    }

    private static IEnumerable<string> ParseLine(string line, char separator)
    {
        var field = new StringBuilder();
        var insideQuotes = false;

        for (var i = 0; i < line.Length; i++)
        {
            var ch = line[i];
            if (ch == '"')
            {
                insideQuotes = !insideQuotes;
            }
            else if (ch == separator && !insideQuotes)
            {
                yield return field.ToString().Trim();
                field.Clear();
            }
            else
            {
                field.Append(ch);
            }
        }

        yield return field.ToString().Trim();
    }
}
