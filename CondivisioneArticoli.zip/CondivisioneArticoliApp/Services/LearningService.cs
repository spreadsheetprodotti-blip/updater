using System.Net.Http;
using System.Text;
using System.Text.Json;
using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class LearningService
{
    private const string AbbreviationsUrl = "https://docs.google.com/spreadsheets/d/1IhJYknMC9HPV4n8yUz7m2TG-_2FmqVJYVMdiYDhu2so/export?format=csv&gid=1815761779";
    private const string LearningUrl = "https://docs.google.com/spreadsheets/d/1IhJYknMC9HPV4n8yUz7m2TG-_2FmqVJYVMdiYDhu2so/export?format=csv&gid=1769410988";
    private const string ScriptUrl = "https://script.google.com/macros/s/AKfycbywKpI2D_uy8m6dlnT53ee5DYBmBkatEg8iiMM8Vb0JTBcWLaie8sjNbOXa_YhcRPnKhw/exec";

    private readonly CsvService _csv = new();
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(10) };
    private readonly List<object> _buffer = [];

    public async Task LoadAbbreviationsAsync(TextNormalizer normalizer, CancellationToken cancellationToken = default)
    {
        var rows = await _csv.DownloadCsvAsync(AbbreviationsUrl, cancellationToken);
        normalizer.SetAbbreviations(rows
            .Skip(1)
            .Where(row => row.Length >= 2)
            .Select(row => (From: row[0], To: row[1])));
    }

    public async Task LoadLearningAsync(AppData data, TextNormalizer normalizer, CancellationToken cancellationToken = default)
    {
        var rows = await _csv.DownloadCsvAsync(LearningUrl, cancellationToken);
        data.LearningItems.Clear();
        data.LearningByDescription.Clear();
        data.LearningByCode.Clear();
        data.LearningSuggestions.Clear();

        foreach (var row in rows.Skip(1))
        {
            var input = Get(row, 0);
            var output = Get(row, 1);
            var code = Get(row, 2);
            if (input.Length == 0 || output.Length == 0)
                continue;

            var item = new LearningItem { Input = input, Output = output, Code = code };
            data.LearningItems.Add(item);

            var key = normalizer.Normalize(input);
            if (key.Length > 0)
            {
                data.LearningByDescription[key] = output;
                if (!data.LearningSuggestions.TryGetValue(key, out var suggestions))
                {
                    suggestions = [];
                    data.LearningSuggestions[key] = suggestions;
                }

                if (!suggestions.Contains(output, StringComparer.OrdinalIgnoreCase))
                    suggestions.Add(output);
            }

            if (code.Length > 0 && !data.LearningByCode.ContainsKey(code))
                data.LearningByCode[code] = output;
        }
    }

    public string? MatchLearning(AppData data, TextNormalizer normalizer, ArticleRow article)
    {
        if (!string.IsNullOrWhiteSpace(article.Code) && data.LearningByCode.TryGetValue(article.Code, out var byCode))
            return byCode;

        var key = normalizer.Normalize(article.Description);
        if (data.LearningByDescription.TryGetValue(key, out var exact))
            return exact;

        var best = data.LearningItems
            .Select(item => new { item.Output, Score = ScoreLearning(normalizer, key, normalizer.Normalize(item.Input)) })
            .Where(x => x.Score >= DynamicThreshold(key))
            .OrderByDescending(x => x.Score)
            .FirstOrDefault();

        return best?.Output;
    }

    public List<string> Suggestions(AppData data, TextNormalizer normalizer, string description, int max)
    {
        var key = normalizer.Normalize(description);
        return data.LearningSuggestions.TryGetValue(key, out var suggestions)
            ? suggestions.Take(max).ToList()
            : [];
    }

    public void QueueLearning(AppData data, TextNormalizer normalizer, ArticleRow article, ProductRow product)
    {
        if (string.IsNullOrWhiteSpace(article.Description) || string.IsNullOrWhiteSpace(product.Name))
            return;

        var normalized = normalizer.Normalize(article.Description);
        if (data.LearningByDescription.TryGetValue(normalized, out var existing) &&
            existing.Equals(product.Name, StringComparison.OrdinalIgnoreCase))
            return;

        _buffer.Add(new
        {
            type = "learning",
            input = Clean(article.Description),
            output = Clean(product.Name),
            codiceC = Clean(product.Code),
            codiceD = Clean(product.SupplierVat)
        });

        if (!string.IsNullOrWhiteSpace(article.Barcode))
        {
            _buffer.Add(new
            {
                type = "barcode",
                product = Clean(product.Name),
                barcode = Clean(article.Barcode)
            });
        }

        data.LearningByDescription[normalized] = product.Name;
    }

    public async Task SendBatchAsync(CancellationToken cancellationToken = default)
    {
        if (_buffer.Count == 0)
            return;

        var json = JsonSerializer.Serialize(_buffer);
        using var content = new StringContent(json, Encoding.UTF8, "application/json");
        using var response = await _http.PostAsync(ScriptUrl, content, cancellationToken);
        response.EnsureSuccessStatusCode();
        _buffer.Clear();
    }

    private static double ScoreLearning(TextNormalizer normalizer, string description, string learningKey)
    {
        var p1 = normalizer.GetWords(description);
        var p2 = normalizer.GetWords(learningKey);
        if (p1.Length == 0 || p2.Length == 0)
            return 0;

        double matchCount = 0;
        foreach (var a in p1)
        {
            var found = false;
            foreach (var b in p2)
            {
                if (a == b)
                {
                    matchCount += 1;
                    found = true;
                    break;
                }

                if (a.Length > 3 && b.Length > 3 && LevenshteinDistance(a, b) <= 1)
                {
                    matchCount += 0.5;
                    found = true;
                    break;
                }
            }

            if (!found)
                matchCount -= 0.3;
        }

        return matchCount / p1.Length;
    }

    private static double DynamicThreshold(string description)
    {
        var count = description.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
        return count switch
        {
            <= 2 => 0.10,
            <= 4 => 0.18,
            <= 7 => 0.25,
            _ => 0.35
        };
    }

    public static int LevenshteinDistance(string source, string target)
    {
        var d = new int[source.Length + 1, target.Length + 1];
        for (var i = 0; i <= source.Length; i++) d[i, 0] = i;
        for (var j = 0; j <= target.Length; j++) d[0, j] = j;

        for (var i = 1; i <= source.Length; i++)
        for (var j = 1; j <= target.Length; j++)
        {
            var cost = source[i - 1] == target[j - 1] ? 0 : 1;
            d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
        }

        return d[source.Length, target.Length];
    }

    private static string Get(string[] row, int index) => index >= 0 && index < row.Length ? row[index].Trim('"', ' ') : "";

    private static string Clean(string value) => value
        .Replace("\"", "'")
        .Replace("\r", " ")
        .Replace("\n", " ")
        .Replace("\t", " ")
        .Trim();
}
