using ClosedXML.Excel;
using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class WorkbookService
{
    public List<ArticleRow> LoadFileRows(string path)
    {
        using var workbook = new XLWorkbook(path);
        var worksheet = workbook.Worksheets.First();
        var used = worksheet.RangeUsed();
        if (used is null)
            return [];

        var rows = new List<ArticleRow>();
        foreach (var row in used.RowsUsed().Skip(1))
        {
            var cells = ReadRow(row, used.ColumnCount());
            if (IsBlank(cells, 0))
                continue;
            if (IsBlank(cells, 2))
                continue;
            if (cells.Length < 26)
                Array.Resize(ref cells, 26);

            cells[25] = "";

            rows.Add(new ArticleRow
            {
                RowNumber = row.RowNumber(),
                Description = Get(cells, 0),
                Code = Get(cells, 1),
                Barcode = Get(cells, 2),
                SupplierVat = TextNormalizer.NormalizeVat(Get(cells, 44)),
                SelectedProduct = Get(cells, 25),
                Cells = cells
            });
        }

        return rows;
    }

    public List<ProductRow> LoadWebRows(string path)
    {
        using var workbook = new XLWorkbook(path);
        var worksheet = workbook.Worksheets.First();
        var used = worksheet.RangeUsed();
        if (used is null)
            return [];

        var rows = new List<ProductRow>();
        foreach (var row in used.RowsUsed().Skip(1))
        {
            var cells = ReadRow(row, used.ColumnCount());
            if (IsBlank(cells, 0))
                continue;

            rows.Add(new ProductRow
            {
                RowNumber = row.RowNumber(),
                Name = Get(cells, 0),
                Code = Get(cells, 1),
                Barcode = Get(cells, 2),
                SupplierVat = TextNormalizer.NormalizeVat(Get(cells, 44)),
                Cells = cells
            });
        }

        return rows;
    }

    public List<SupplierRow> LoadSuppliers(string path)
    {
        using var workbook = new XLWorkbook(path);
        var worksheet = workbook.Worksheets.First();
        var used = worksheet.RangeUsed();
        if (used is null)
            return [];

        var rows = new List<SupplierRow>();
        foreach (var row in used.RowsUsed().Skip(1))
        {
            var cells = ReadRow(row, used.ColumnCount());
            var vat = TextNormalizer.NormalizeVat(Get(cells, 10));
            if (vat.Length == 0)
                continue;

            rows.Add(new SupplierRow
            {
                Name = Get(cells, 0),
                Vat = vat,
                Cells = cells
            });
        }

        return rows;
    }

    public List<string[]> LoadRawRows(string path)
    {
        using var workbook = new XLWorkbook(path);
        var worksheet = workbook.Worksheets.First();
        var used = worksheet.RangeUsed();
        if (used is null)
            return [];

        return used.RowsUsed()
            .Select(row => ReadRow(row, used.ColumnCount()))
            .ToList();
    }

    public void SaveResults(string path, IEnumerable<ArticleRow> rows)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.AddWorksheet("RISULTATO");

        var rowIndex = 1;
        foreach (var row in rows)
        {
            var cells = row.Cells.Length > 0 ? row.Cells.ToArray() : new string[26];
            if (cells.Length < 26)
                Array.Resize(ref cells, 26);

            cells[25] = row.SelectedProduct;

            for (var col = 0; col < cells.Length; col++)
                worksheet.Cell(rowIndex, col + 1).Value = cells[col];

            rowIndex++;
        }

        worksheet.Columns().AdjustToContents();
        workbook.SaveAs(path);
    }

    public void SaveTwoPartResults(string firstPath, string secondPath, IEnumerable<ArticleRow> rows, IEnumerable<ProductRow> products)
    {
        var productCodes = products
            .GroupBy(product => product.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First().Code, StringComparer.OrdinalIgnoreCase);

        using var first = new XLWorkbook();
        using var second = new XLWorkbook();
        var ws1 = first.AddWorksheet("PRIMA PARTE");
        var ws2 = second.AddWorksheet("SECONDA PARTE");

        var headers = new[] { "Risultato scelto", "Codice", "AO FILE", "O FILE" };
        for (var i = 0; i < headers.Length; i++)
        {
            ws1.Cell(1, i + 1).Value = i == 1 ? "Codice FILE" : headers[i];
            ws2.Cell(1, i + 1).Value = i == 1 ? "Codice WEB" : headers[i];
        }

        var rowIndex = 2;
        foreach (var row in rows.Where(row => !string.IsNullOrWhiteSpace(row.SelectedProduct)))
        {
            var codeFile = Get(row.Cells, 1);
            var aoFile = Get(row.Cells, 40);
            var oFile = Get(row.Cells, 14);
            productCodes.TryGetValue(row.SelectedProduct, out var codeWeb);

            ws1.Cell(rowIndex, 1).Value = row.SelectedProduct;
            ws1.Cell(rowIndex, 2).Value = codeFile;
            ws1.Cell(rowIndex, 3).Value = aoFile;
            ws1.Cell(rowIndex, 4).Value = oFile;

            ws2.Cell(rowIndex, 1).Value = row.SelectedProduct;
            ws2.Cell(rowIndex, 2).Value = codeWeb ?? "";
            ws2.Cell(rowIndex, 3).Value = aoFile;
            ws2.Cell(rowIndex, 4).Value = oFile;

            rowIndex++;
        }

        ws1.Columns().AdjustToContents();
        ws2.Columns().AdjustToContents();
        first.SaveAs(firstPath);
        second.SaveAs(secondPath);
    }

    public void SaveSupplierExportFolder(
        string folder,
        IReadOnlySet<string> selectedSupplierVats,
        IReadOnlyList<SupplierRow> suppliers,
        IReadOnlyList<ProductRow> products,
        IReadOnlyList<string[]> categories,
        IReadOnlyList<string[]> barcodes)
    {
        Directory.CreateDirectory(folder);

        SaveRows(Path.Combine(folder, "Export_Fornitori.xlsx"),
            suppliers
                .Where(supplier => selectedSupplierVats.Contains(supplier.Vat))
                .Select(supplier =>
                {
                    var cells = new string[Math.Max(11, supplier.Cells.Length)];
                    cells[0] = supplier.Vat;
                    cells[1] = "0";
                    cells[2] = Get(supplier.Cells, 0);
                    cells[3] = Get(supplier.Cells, 2);
                    cells[4] = Get(supplier.Cells, 3);
                    cells[5] = Get(supplier.Cells, 4);
                    cells[6] = Get(supplier.Cells, 5);
                    cells[7] = Get(supplier.Cells, 6);
                    cells[8] = Get(supplier.Cells, 7);
                    cells[9] = Get(supplier.Cells, 8);
                    cells[10] = Get(supplier.Cells, 9);
                    return cells;
                }));

        SaveRows(Path.Combine(folder, "Export_Categorie_Padre.xlsx"),
            categories.Skip(1).Where(row => string.IsNullOrWhiteSpace(Get(row, 1))));

        SaveRows(Path.Combine(folder, "Export_Categorie_Figlio.xlsx"),
            categories.Skip(1).Where(row => !string.IsNullOrWhiteSpace(Get(row, 1))));

        var filteredProducts = products
            .Where(product => selectedSupplierVats.Contains(product.SupplierVat) || product.Code.StartsWith("GEN", StringComparison.OrdinalIgnoreCase))
            .GroupBy(product => product.Code, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.First())
            .ToList();

        SaveRows(Path.Combine(folder, "Export_Inventario.xlsx"), filteredProducts.Select(product => product.Cells));

        var productCodes = filteredProducts.Select(product => product.Code).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var seenBarcodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        SaveRows(Path.Combine(folder, "Export_Barcodes.xlsx"),
            barcodes.Skip(1).Where(row =>
            {
                var code = Get(row, 0);
                var barcode = Get(row, 1);
                if (!productCodes.Contains(code))
                    return false;
                if (barcode.Length == 0)
                    return true;
                return seenBarcodes.Add(barcode);
            }));
    }

    private static void SaveRows(string path, IEnumerable<string[]> rows)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.AddWorksheet("Export");
        var rowIndex = 1;
        foreach (var row in rows)
        {
            for (var col = 0; col < row.Length; col++)
                worksheet.Cell(rowIndex, col + 1).Value = row[col];
            rowIndex++;
        }

        worksheet.Columns().AdjustToContents();
        workbook.SaveAs(path);
    }

    private static string[] ReadRow(IXLRangeRow row, int columnCount)
    {
        var cells = new string[columnCount];
        for (var i = 1; i <= columnCount; i++)
            cells[i - 1] = row.Cell(i).GetFormattedString().Trim();
        return cells;
    }

    private static string Get(string[] cells, int index) =>
        index >= 0 && index < cells.Length ? cells[index] : "";

    private static bool IsBlank(string[] cells, int index) => string.IsNullOrWhiteSpace(Get(cells, index));
}
