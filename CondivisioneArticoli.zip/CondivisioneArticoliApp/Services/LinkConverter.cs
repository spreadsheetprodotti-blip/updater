namespace CondivisioneArticoliApp.Services;

public static class LinkConverter
{
    public static string ConvertToRaw(string link)
    {
        link = link.Trim();

        if (link.Contains("raw.githubusercontent.com", StringComparison.OrdinalIgnoreCase))
            return link;

        if (!link.Contains("github.com/", StringComparison.OrdinalIgnoreCase))
            return "";

        var path = link[(link.IndexOf("github.com/", StringComparison.OrdinalIgnoreCase) + "github.com/".Length)..];
        path = path.Replace("/blob/", "/", StringComparison.OrdinalIgnoreCase)
                   .Replace("/raw/", "/", StringComparison.OrdinalIgnoreCase)
                   .Replace("/refs/heads/", "/", StringComparison.OrdinalIgnoreCase);

        return "https://raw.githubusercontent.com/" + path;
    }
}
