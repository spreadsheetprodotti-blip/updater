using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class AppRepository
{
    private readonly WorkbookService _workbooks = new();
    private readonly DownloadService _downloads = new();
    private readonly LearningService _learning = new();
    private readonly AppCacheService _cache = new();

    public AppData Data { get; } = new();

    public LearningService Learning => _learning;

    public AppCacheService Cache => _cache;

    public bool TryLoadCache() => _cache.TryLoad(Data);

    public void SaveCache() => _cache.Save(Data);

    public void ClearSavedData()
    {
        Data.FileRows.Clear();
        Data.WebRows.Clear();
        Data.Suppliers.Clear();
        Data.Categories.Clear();
        Data.Barcodes.Clear();
        Data.LearningItems.Clear();
        Data.LearningByDescription.Clear();
        Data.LearningByCode.Clear();
        Data.LearningSuggestions.Clear();
        _cache.Clear();
    }

    public async Task LoadRemoteLookupsAsync(TextNormalizer normalizer, IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        progress?.Report("Carico abbreviazioni...");
        await _learning.LoadAbbreviationsAsync(normalizer, cancellationToken);

        progress?.Report("Carico learning...");
        await _learning.LoadLearningAsync(Data, normalizer, cancellationToken);
        SaveCache();
    }

    public async Task DownloadWebCatalogAsync(IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        var temp = Path.Combine(Path.GetTempPath(), "ExportArticoli.xlsx");
        progress?.Report("Scarico catalogo articoli...");
        await _downloads.DownloadFileAsync("https://github.com/spreadsheetprodotti-blip/updater/raw/refs/heads/main/ExportArticoli.xlsx", temp, cancellationToken);

        Data.WebRows.Clear();
        Data.WebRows.AddRange(_workbooks.LoadWebRows(temp));
        SaveCache();
    }

    public async Task DownloadSuppliersAsync(IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        var temp = Path.Combine(Path.GetTempPath(), "ExportFornitori.xlsx");
        progress?.Report("Scarico fornitori...");
        await _downloads.DownloadFileAsync("https://github.com/spreadsheetprodotti-blip/updater/raw/96c520f69eb1110b125b18fa726f126da242271f/ExportFornitori.xlsx", temp, cancellationToken);

        Data.Suppliers.Clear();
        Data.Suppliers.AddRange(_workbooks.LoadSuppliers(temp));
        SaveCache();
    }

    public async Task DownloadFullInventoryAsync(IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        await DownloadWebCatalogAsync(progress, cancellationToken);
        await DownloadSuppliersAsync(progress, cancellationToken);

        var categories = Path.Combine(Path.GetTempPath(), "exportCategories.xlsx");
        progress?.Report("Scarico categorie...");
        await _downloads.DownloadFileAsync("https://raw.githubusercontent.com/spreadsheetprodotti-blip/updater/main/exportCategories.xlsx", categories, cancellationToken);
        Data.Categories.Clear();
        Data.Categories.AddRange(_workbooks.LoadRawRows(categories));

        var barcodes = Path.Combine(Path.GetTempPath(), "exportBarcodes.xlsx");
        progress?.Report("Scarico barcode...");
        await _downloads.DownloadFileAsync("https://raw.githubusercontent.com/spreadsheetprodotti-blip/updater/main/exportBarcodes.xlsx", barcodes, cancellationToken);
        Data.Barcodes.Clear();
        Data.Barcodes.AddRange(_workbooks.LoadRawRows(barcodes));
        SaveCache();
    }

    public void LoadFile(string path)
    {
        Data.FileRows.Clear();
        Data.FileRows.AddRange(_workbooks.LoadFileRows(path));
        SaveCache();
    }

    public void SaveResults(string path) => _workbooks.SaveResults(path, Data.FileRows);

    public void SaveTwoPartResults(string firstPath, string secondPath) =>
        _workbooks.SaveTwoPartResults(firstPath, secondPath, Data.FileRows, Data.WebRows);

    public void SaveSupplierExportFolder(string folder, IReadOnlySet<string> selectedSupplierVats) =>
        _workbooks.SaveSupplierExportFolder(folder, selectedSupplierVats, Data.Suppliers, Data.WebRows, Data.Categories, Data.Barcodes);
}
