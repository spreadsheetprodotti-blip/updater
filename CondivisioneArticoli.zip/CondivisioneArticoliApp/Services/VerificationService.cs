using System.Text;
using CondivisioneArticoliApp.Models;

namespace CondivisioneArticoliApp.Services;

public sealed class VerificationService
{
    public string BuildReport(AppData data)
    {
        var selected = data.FileRows.Where(row => !string.IsNullOrWhiteSpace(row.SelectedProduct)).ToList();
        var productCodes = data.WebRows
            .GroupBy(row => row.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First().Code, StringComparer.OrdinalIgnoreCase);

        var missingWebCode = selected
            .Where(row => !productCodes.TryGetValue(row.SelectedProduct, out var code) || string.IsNullOrWhiteSpace(code))
            .Take(30)
            .ToList();

        var duplicateFileCodes = data.FileRows
            .Where(row => !string.IsNullOrWhiteSpace(row.Code))
            .GroupBy(row => row.Code, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Take(20)
            .ToList();

        var duplicateBarcodes = data.FileRows
            .Where(row => !string.IsNullOrWhiteSpace(row.Barcode))
            .GroupBy(row => row.Barcode, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Take(20)
            .ToList();

        var builder = new StringBuilder();
        builder.AppendLine("VERIFICA DATI");
        builder.AppendLine();
        builder.AppendLine($"Righe FILE: {data.FileRows.Count}");
        builder.AppendLine($"Articoli WEB: {data.WebRows.Count}");
        builder.AppendLine($"Fornitori: {data.Suppliers.Count}");
        builder.AppendLine($"Categorie: {data.Categories.Count}");
        builder.AppendLine($"Barcode WEB: {data.Barcodes.Count}");
        builder.AppendLine($"Learning: {data.LearningItems.Count}");
        builder.AppendLine();
        builder.AppendLine($"Righe selezionate: {selected.Count}");
        builder.AppendLine($"Righe ancora vuote: {data.FileRows.Count - selected.Count}");
        builder.AppendLine();

        AppendSection(builder, "Prodotti selezionati senza codice WEB", missingWebCode.Select(row => $"{row.Description} -> {row.SelectedProduct}"));
        AppendSection(builder, "Codici FILE duplicati", duplicateFileCodes.Select(group => $"{group.Key}: {group.Count()} righe"));
        AppendSection(builder, "Barcode FILE duplicati", duplicateBarcodes.Select(group => $"{group.Key}: {group.Count()} righe"));

        if (missingWebCode.Count == 0 && duplicateFileCodes.Count == 0 && duplicateBarcodes.Count == 0)
            builder.AppendLine("Nessun problema evidente trovato.");

        return builder.ToString();
    }

    private static void AppendSection(StringBuilder builder, string title, IEnumerable<string> rows)
    {
        var list = rows.ToList();
        if (list.Count == 0)
            return;

        builder.AppendLine(title + ":");
        foreach (var row in list)
            builder.AppendLine(" - " + row);
        builder.AppendLine();
    }
}
