using System.Net.Http;

namespace CondivisioneArticoliApp.Services;

public sealed class DownloadService
{
    private readonly HttpClient _http = new();

    public async Task DownloadFileAsync(string url, string destination, CancellationToken cancellationToken = default)
    {
        using var response = await _http.GetAsync(url, cancellationToken);
        response.EnsureSuccessStatusCode();

        await using var input = await response.Content.ReadAsStreamAsync(cancellationToken);
        await using var output = File.Create(destination);
        await input.CopyToAsync(output, cancellationToken);
    }
}
