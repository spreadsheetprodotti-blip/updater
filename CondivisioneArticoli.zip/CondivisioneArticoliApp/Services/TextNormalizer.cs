using System.Text;

namespace CondivisioneArticoliApp.Services;

public sealed class TextNormalizer
{
    private readonly Dictionary<string, string> _abbreviations = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string[]> _synonyms = new(StringComparer.OrdinalIgnoreCase)
    {
        ["zero"] = ["senza", "zucchero"],
        ["light"] = ["leggero"],
        ["regular"] = ["classico"],
        ["normale"] = ["classico"]
    };

    public void SetAbbreviations(IEnumerable<(string From, string To)> items)
    {
        _abbreviations.Clear();
        foreach (var item in items)
        {
            var from = item.From.Trim().ToLowerInvariant();
            var to = item.To.Trim().ToLowerInvariant();
            if (from.Length > 0)
                _abbreviations[from] = to;
        }
    }

    public string Normalize(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return "";

        var builder = new StringBuilder(text.ToLowerInvariant());
        builder.Replace('.', ' ')
               .Replace('-', ' ')
               .Replace(',', ' ')
               .Replace('\t', ' ')
               .Replace('\u00A0', ' ');

        var words = builder.ToString()
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(word => _abbreviations.TryGetValue(word, out var expanded) ? expanded : word);

        return string.Join(' ', words);
    }

    public string[] GetWords(string? text) =>
        Normalize(text).Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

    public string[] ExpandSynonyms(IEnumerable<string> words)
    {
        var output = new List<string>();
        foreach (var word in words)
        {
            if (string.IsNullOrWhiteSpace(word))
                continue;

            output.Add(word);
            if (_synonyms.TryGetValue(word, out var expanded))
                output.AddRange(expanded);
        }

        return output.ToArray();
    }

    public static string NormalizeVat(string? value)
    {
        var text = (value ?? "").Trim().Replace("\u00A0", "").Replace(" ", "");
        if (text.StartsWith("IT", StringComparison.OrdinalIgnoreCase))
            text = text[2..];

        return text.TrimStart('0');
    }

    public static bool ContainsDigit(string value) => value.Any(char.IsDigit);

    public static string NormalizeNumber(string word)
    {
        word = word.Trim().ToLowerInvariant().Replace(',', '.');
        var numberText = new string(word.TakeWhile(ch => char.IsDigit(ch) || ch == '.').ToArray());
        if (!double.TryParse(numberText, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var number))
            return word;

        var unit = word[numberText.Length..];
        return unit switch
        {
            "l" => $"{number * 1000:0.##}ml",
            "cl" => $"{number * 10:0.##}ml",
            "kg" => $"{number * 1000:0.##}g",
            "g" or "ml" => $"{number:0.##}{unit}",
            _ => word
        };
    }
}
