namespace CondivisioneArticoliApp.Models;

public sealed class LearningItem
{
    public string Input { get; set; } = "";
    public string Output { get; set; } = "";
    public string Code { get; set; } = "";
}
