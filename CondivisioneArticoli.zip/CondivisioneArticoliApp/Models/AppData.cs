namespace CondivisioneArticoliApp.Models;

public sealed class AppData
{
    public List<ArticleRow> FileRows { get; } = [];
    public List<ProductRow> WebRows { get; } = [];
    public List<SupplierRow> Suppliers { get; } = [];
    public List<string[]> Categories { get; } = [];
    public List<string[]> Barcodes { get; } = [];
    public List<LearningItem> LearningItems { get; } = [];
    public Dictionary<string, string> LearningByDescription { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, string> LearningByCode { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, List<string>> LearningSuggestions { get; } = new(StringComparer.OrdinalIgnoreCase);
}
