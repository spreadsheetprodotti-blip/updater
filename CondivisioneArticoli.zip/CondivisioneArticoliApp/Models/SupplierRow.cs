namespace CondivisioneArticoliApp.Models;

public sealed class SupplierRow
{
    public string Name { get; set; } = "";
    public string Vat { get; set; } = "";
    public string[] Cells { get; set; } = [];
}
