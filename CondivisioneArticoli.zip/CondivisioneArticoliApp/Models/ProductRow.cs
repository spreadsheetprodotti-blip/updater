namespace CondivisioneArticoliApp.Models;

public sealed class ProductRow
{
    public int RowNumber { get; set; }
    public string Name { get; set; } = "";
    public string Code { get; set; } = "";
    public string Barcode { get; set; } = "";
    public string SupplierVat { get; set; } = "";
    public string[] Cells { get; set; } = [];
}
