namespace CondivisioneArticoliApp.Forms;

public sealed class InventoryResetForm : Form
{
    public InventoryResetForm()
    {
        Text = "Azzeramento inventario";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 720;
        Height = 460;
        MinimumSize = new Size(640, 390);

        var header = Ui.Card(24, 24, 620, 82);
        header.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.BorderStyle = BorderStyle.None;
        header.BackColor = Color.FromArgb(232, 240, 249);

        var title = Ui.Label("Azzeramento inventario", true);
        title.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        title.SetBounds(18, 10, 560, 38);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        var subtitle = Ui.Label("Area dedicata alla preparazione dell'inventario da azzerare.");
        subtitle.ForeColor = Ui.TextMuted;
        subtitle.SetBounds(20, 50, 560, 22);
        subtitle.AutoSize = false;
        subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        header.Controls.AddRange([title, subtitle]);

        var note = Ui.Label("Funzione pronta per essere collegata al flusso operativo.");
        note.SetBounds(32, 140, 600, 28);
        note.AutoSize = false;
        note.ForeColor = Ui.TextMuted;

        var back = Ui.Button("Indietro", 120, 38);
        back.SetBounds(32, 340, 120, 38);
        back.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        back.Click += (_, _) => Close();

        Controls.AddRange([header, note, back]);
    }
}
