using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class ExportForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextNormalizer _normalizer = new();

    public ExportForm(AppRepository repository)
    {
        _repository = repository;

        Text = "Export inventario";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 520;
        Height = 390;
        MinimumSize = new Size(500, 370);
        AutoScroll = true;

        var header = Ui.Card(24, 24, 450, 78);
        header.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.BorderStyle = BorderStyle.None;
        header.BackColor = Color.FromArgb(232, 240, 249);
        var title = Ui.Label("Export inventario", true);
        title.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        title.SetBounds(16, 8, 400, 36);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        var subtitle = Ui.Label("Scarica i dati e crea gli export filtrati.");
        subtitle.ForeColor = Ui.TextMuted;
        subtitle.SetBounds(18, 46, 400, 20);
        subtitle.AutoSize = false;
        subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.Controls.AddRange([title, subtitle]);

        var download = Ui.Button("Scarica inventario", 320, 52, primary: true);
        download.SetBounds(74, 132, 320, 52);
        download.Click += async (_, _) =>
        {
            using var update = new UpdateForm("Scarico inventario...");
            update.Show(this);
            await _repository.DownloadFullInventoryAsync(new Progress<string>(m => update.Status = m));
            await _repository.LoadRemoteLookupsAsync(_normalizer, new Progress<string>(m => update.Status = m));
            update.Close();
        };

        var control = Ui.Button("Seleziona fornitori", 320, 52);
        control.SetBounds(74, 208, 320, 52);
        control.Click += (_, _) => ShowChild(new SupplierExportForm(_repository));

        var back = Ui.Button("Indietro", 120, 36);
        back.SetBounds(24, 292, 120, 38);
        back.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        back.Click += (_, _) => Close();

        Controls.AddRange([header, download, control, back]);
    }

    private void ShowChild(Form child)
    {
        Hide();
        try
        {
            child.ShowDialog();
        }
        finally
        {
            Show();
            Activate();
        }
    }
}
