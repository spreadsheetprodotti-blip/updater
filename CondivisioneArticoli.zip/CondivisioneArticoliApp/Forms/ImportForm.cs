using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class ImportForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextNormalizer _normalizer;
    private readonly Label _status = Ui.Label("");

    public ImportForm(AppRepository repository, TextNormalizer normalizer)
    {
        _repository = repository;
        _normalizer = normalizer;

        Text = "Importazione dati";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 560;
        Height = 390;
        MinimumSize = new Size(540, 360);
        AutoScroll = true;

        var header = Ui.Card(24, 24, 480, 68);
        header.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.BorderStyle = BorderStyle.None;
        header.BackColor = Color.FromArgb(232, 240, 249);
        var title = Ui.Label("Importazione dati", true);
        title.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        title.SetBounds(16, 10, 420, 28);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        var subtitle = Ui.Label("Carica file locali o aggiorna i dati online.");
        subtitle.ForeColor = Ui.TextMuted;
        subtitle.SetBounds(18, 38, 420, 20);
        subtitle.AutoSize = false;
        subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.Controls.AddRange([title, subtitle]);

        var importWeb = Ui.Button("Importa da web", 210, 46, primary: true);
        importWeb.SetBounds(36, 118, 210, 46);
        importWeb.Click += async (_, _) => await RunAsync("Importazione web...", async progress =>
        {
            await _repository.DownloadWebCatalogAsync(progress);
            await _repository.DownloadSuppliersAsync(progress);
            await _repository.LoadRemoteLookupsAsync(_normalizer, progress);
        });

        var importFile = Ui.Button("Importa da file", 210, 46);
        importFile.SetBounds(276, 118, 210, 46);
        importFile.Click += (_, _) => ImportLocalFile();

        var compare = Ui.Button("Compara dati", 210, 46);
        compare.SetBounds(36, 186, 210, 46);
        compare.Click += (_, _) => MessageBox.Show(this,
            $"FILE: {_repository.Data.FileRows.Count} righe{Environment.NewLine}WEB: {_repository.Data.WebRows.Count} articoli",
            "Dati caricati");

        var export = Ui.Button("Esporta risultato", 210, 46);
        export.SetBounds(276, 186, 210, 46);
        export.Click += (_, _) => ExportResults();

        _status.SetBounds(36, 274, 455, 26);
        _status.AutoSize = false;
        _status.ForeColor = Ui.TextMuted;

        Controls.AddRange([header, importWeb, importFile, compare, export, _status]);
    }

    private void ImportLocalFile()
    {
        using var dialog = new OpenFileDialog
        {
            Filter = "File Excel|*.xlsx;*.xlsm;*.xls",
            Title = "Seleziona file da caricare"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            _repository.LoadFile(dialog.FileName);
            _status.Text = $"File caricato: {_repository.Data.FileRows.Count} righe";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore import", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ExportResults()
    {
        using var dialog = new SaveFileDialog
        {
            Filter = "File Excel|*.xlsx",
            FileName = "Risultato.xlsx"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            _repository.SaveResults(dialog.FileName);
            _status.Text = "Risultato esportato";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task RunAsync(string startMessage, Func<IProgress<string>, Task> action)
    {
        try
        {
            _status.Text = startMessage;
            var progress = new Progress<string>(message => _status.Text = message);
            await action(progress);
            _status.Text = "Operazione completata";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _status.Text = "Errore";
        }
    }
}
