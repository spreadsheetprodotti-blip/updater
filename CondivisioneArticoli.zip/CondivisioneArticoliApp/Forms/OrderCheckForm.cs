using CondivisioneArticoliApp.Models;
using CondivisioneArticoliApp.Services;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text.Json;
using UglyToad.PdfPig;

namespace CondivisioneArticoliApp.Forms;

public sealed class OrderCheckForm : Form
{
    private const string CatalogUrl = "https://github.com/spreadsheetprodotti-blip/updater/raw/refs/heads/main/Catalogo.xlsx";
    private const string BarcodeCsvUrl = "https://github.com/spreadsheetprodotti-blip/updater/raw/refs/heads/main/exportBarcodes.CSV";
    private static readonly string[] AdmPdfUrls =
    [
        "https://www.adm.gov.it/portale/documents/20182/1106899/3.2-LIST+SIGARI.pdf/bd227503-9779-bf56-c817-c19cfb853a64?t=1778048403525",
        "https://www.adm.gov.it/portale/documents/20182/1106899/2.2-LIST+SIGARETTI.pdf/5effe15a-5155-0da3-bf0b-356abaa63b5e?t=1777357869723",
        "https://www.adm.gov.it/portale/documents/20182/1106899/LIST+FIUTO+16012026.pdf/39984a1d-f097-a966-e242-d52cb9fdd28e?t=1768547110231",
        "https://www.adm.gov.it/portale/documents/20182/1106899/3.2-LIST+RYO.pdf/3df140a5-7d0b-adb8-d136-3997f8e49aa3?t=1776232077409",
        "https://www.adm.gov.it/portale/documents/20182/1106899/3.3-LIST+ALTRI.pdf/75a11193-eaaa-bd6e-f754-1def21fc17b2?t=1778048531519",
        "https://www.adm.gov.it/portale/documents/20182/1106899/3.1-LIST+SIGARETTE.pdf/42c96880-1905-fbb1-7d19-caf6a7bcc57a?t=1778048245912"
    ];
    private static readonly Regex AdmLineRegex = new(
        @"(?<code>\d{1,6})\s*.+?\s+da\s+(?<amount>\d+)\s+(?<unit>pezzi|grammi)\s*(?<kg>[\d.]+,\d{2})\s*(?<pack>[\d.]+,\d{2})",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private readonly WorkbookService _workbooks = new();
    private readonly DownloadService _downloads = new();
    private readonly AppRepository _repository;
    private readonly CsvService _csv = new();
    private readonly TextBox _barcodeInput = new();
    private readonly NumericUpDown _quantityInput = new();
    private readonly ListView _items = new();
    private readonly Label _status = Ui.Label("");
    private readonly Dictionary<string, ScanLine> _linesByBarcode = new(StringComparer.OrdinalIgnoreCase);
    private List<string[]> _barcodeRows = [];
    private Dictionary<string, BarcodeProductInfo> _productsByBarcode = new(StringComparer.OrdinalIgnoreCase);
    private Dictionary<string, decimal> _packageWeightGramsByCode = new(StringComparer.OrdinalIgnoreCase);
    private bool _productsLoaded;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };
    private static string CacheFolder => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "CondivisioneArticoliApp");
    private static string AdmWeightsCachePath => Path.Combine(CacheFolder, "adm-weights.json");

    public OrderCheckForm(AppRepository repository)
    {
        _repository = repository;

        Text = "Spunta ordine";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 980;
        Height = 720;
        MinimumSize = new Size(820, 620);

        var header = Ui.Card(24, 24, 860, 82);
        header.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.BorderStyle = BorderStyle.None;
        header.BackColor = Color.FromArgb(232, 240, 249);

        var title = Ui.Label("Spunta ordine", true);
        title.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        title.SetBounds(18, 10, 560, 38);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        var subtitle = Ui.Label("Area dedicata al controllo degli articoli ricevuti rispetto all'ordine.");
        subtitle.ForeColor = Ui.TextMuted;
        subtitle.SetBounds(20, 50, 560, 22);
        subtitle.AutoSize = false;
        subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        header.Controls.AddRange([title, subtitle]);

        var refreshOnline = Ui.Button("Aggiorna online", 150, 42, primary: true);
        refreshOnline.SetBounds(32, 130, 150, 42);
        refreshOnline.Click += async (_, _) => await LoadProductsAsync(forceDownload: true);

        var inputLabel = Ui.Label("Codice a barre");
        inputLabel.SetBounds(32, 196, 130, 22);
        inputLabel.AutoSize = false;

        _barcodeInput.SetBounds(32, 222, 360, 32);
        _barcodeInput.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        Ui.StyleInput(_barcodeInput);
        _barcodeInput.KeyDown += (_, e) =>
        {
            if (e.KeyCode != Keys.Enter)
                return;

            e.SuppressKeyPress = true;
            RegisterBarcode(_barcodeInput.Text);
            _barcodeInput.Clear();
        };

        var quantityLabel = Ui.Label("Quantita");
        quantityLabel.SetBounds(420, 196, 120, 22);
        quantityLabel.AutoSize = false;

        _quantityInput.SetBounds(420, 222, 110, 32);
        _quantityInput.Minimum = 1;
        _quantityInput.Maximum = 10000;
        _quantityInput.Value = 1;
        _quantityInput.DecimalPlaces = 0;
        _quantityInput.TextAlign = HorizontalAlignment.Right;
        Ui.StyleInput(_quantityInput);

        _items.SetBounds(32, 282, 880, 300);
        _items.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        _items.View = View.Details;
        _items.FullRowSelect = true;
        _items.HideSelection = false;
        Ui.StyleGrid(_items);
        _items.Columns.Add("Barcode", 150);
        _items.Columns.Add("Prodotto", 420);
        _items.Columns.Add("Codice", 130);
        _items.Columns.Add("Confezioni", 95);
        _items.Columns.Add("Moltiplicatore", 110);
        _items.Columns.Add("Peso stimato", 120);

        var clear = Ui.Button("Svuota lista", 120, 38);
        clear.SetBounds(178, 610, 120, 40);
        clear.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        clear.Click += (_, _) =>
        {
            _linesByBarcode.Clear();
            RefreshList();
            _barcodeInput.Focus();
        };

        var back = Ui.Button("Indietro", 120, 38);
        back.SetBounds(32, 610, 120, 40);
        back.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        back.Click += (_, _) => Close();

        _status.SetBounds(330, 617, 580, 26);
        _status.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
        _status.AutoSize = false;
        _status.ForeColor = Ui.TextMuted;
        _status.TextAlign = ContentAlignment.MiddleRight;

        Controls.AddRange([header, refreshOnline, inputLabel, _barcodeInput, quantityLabel, _quantityInput, _items, back, clear, _status]);
        Resize += (_, _) => ResizeColumns();
        BuildBarcodeIndex();
        UpdateStatus();
        Shown += async (_, _) =>
        {
            if (!_productsLoaded)
                await LoadProductsAsync(forceDownload: false, showCompletionMessage: false);
            _barcodeInput.Focus();
        };
    }

    private async Task LoadProductsAsync(bool forceDownload, bool showCompletionMessage = true)
    {
        try
        {
            using var progress = new UpdateForm("Caricamento prodotti online...");
            progress.Show(this);
            progress.Refresh();

            var catalogPath = await GetCachedFileAsync("Catalogo-spunta.xlsx", CatalogUrl, forceDownload, "catalogo", progress);
            _repository.Data.WebRows.Clear();
            _repository.Data.WebRows.AddRange(_workbooks.LoadWebRows(catalogPath));

            var barcodePath = await GetCachedFileAsync("exportBarcodes-spunta.CSV", BarcodeCsvUrl, forceDownload, "barcode", progress);
            _barcodeRows = CsvService.Parse(await File.ReadAllTextAsync(barcodePath), ';');

            progress.Status = "Carico pesi ADM...";
            _packageWeightGramsByCode = await LoadAdmWeightsCachedAsync(progress, forceDownload);
            progress.Close();

            BuildBarcodeIndex();
            _productsLoaded = _productsByBarcode.Count > 0;
            UpdateStatus("Articoli, barcode e pesi ADM caricati.");
            if (showCompletionMessage)
            {
                MessageBox.Show(this,
                    $"Caricati:{Environment.NewLine}" +
                    $"Articoli: {_repository.Data.WebRows.Count}{Environment.NewLine}" +
                    $"Barcode: {_productsByBarcode.Count}{Environment.NewLine}" +
                    $"Pesi ADM: {_packageWeightGramsByCode.Count}{Environment.NewLine}" +
                    $"Origine: {(forceDownload ? "aggiornata online" : "cache locale")}",
                    "Caricamento completato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            _barcodeInput.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore caricamento prodotti", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task<string> GetCachedFileAsync(string fileName, string url, bool forceDownload, string label, UpdateForm progress)
    {
        Directory.CreateDirectory(CacheFolder);
        var path = Path.Combine(CacheFolder, fileName);
        if (!forceDownload && File.Exists(path) && new FileInfo(path).Length > 0)
        {
            progress.Status = $"Uso {label} salvato...";
            return path;
        }

        progress.Status = $"Scarico {label}...";
        await _downloads.DownloadFileAsync(url, path);
        return path;
    }

    private void BuildBarcodeIndex()
    {
        var byCode = _repository.Data.WebRows
            .Where(product => !string.IsNullOrWhiteSpace(product.Code))
            .GroupBy(product => NormalizeCode(product.Code), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

        var index = new Dictionary<string, ProductRow>(StringComparer.OrdinalIgnoreCase);
        foreach (var product in _repository.Data.WebRows)
        {
            var barcode = NormalizeBarcode(product.Barcode);
            if (barcode.Length > 0 && !index.ContainsKey(barcode))
                index[barcode] = product;
        }

        var barcodeInfo = new Dictionary<string, BarcodeProductInfo>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in index)
            barcodeInfo[item.Key] = new BarcodeProductInfo(item.Value, 1m);

        foreach (var row in _barcodeRows)
        {
            var code = NormalizeCode(Get(row, 0));
            var barcode = NormalizeBarcode(Get(row, 1));
            if (barcode.Length == 0 || !byCode.TryGetValue(code, out var product))
                continue;

            var multiplier = TryParseItalianDecimal(Get(row, 4), out var parsedMultiplier) && parsedMultiplier > 0
                ? parsedMultiplier
                : 1m;
            barcodeInfo.TryAdd(barcode, new BarcodeProductInfo(product, multiplier));
        }

        _productsByBarcode = barcodeInfo;
        ResizeColumns();
    }

    private void RegisterBarcode(string value)
    {
        var barcode = NormalizeBarcode(value);
        if (barcode.Length == 0)
            return;

        if (!_productsLoaded || _productsByBarcode.Count == 0)
        {
            MessageBox.Show(this,
                "Prima premi 'Carica prodotti online' e attendi il messaggio di caricamento completato.",
                "Prodotti non caricati",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            _barcodeInput.Focus();
            return;
        }

        if (!_linesByBarcode.TryGetValue(barcode, out var line))
        {
            _productsByBarcode.TryGetValue(barcode, out var info);
            var product = info?.Product;
            line = new ScanLine
            {
                Barcode = barcode,
                ProductName = product?.Name ?? "Prodotto non trovato",
                ProductCode = product?.Code ?? "",
                Multiplier = info?.Multiplier ?? 1m,
                PackageWeightGrams = product is not null && _packageWeightGramsByCode.TryGetValue(NormalizeCode(product.Code), out var grams)
                    ? grams
                    : null
            };
            _linesByBarcode[barcode] = line;
        }

        line.Packages += line.Multiplier * _quantityInput.Value;
        RefreshList();
        UpdateStatus(line.ProductName == "Prodotto non trovato"
            ? $"Barcode non trovato: {barcode} - indice barcode caricati: {_productsByBarcode.Count}"
            : $"Aggiunto: {line.ProductName}");
    }

    private void RefreshList()
    {
        _items.BeginUpdate();
        _items.Items.Clear();
        foreach (var line in _linesByBarcode.Values.OrderBy(line => line.ProductName))
        {
            var item = new ListViewItem(line.Barcode);
            item.SubItems.Add(line.ProductName);
            item.SubItems.Add(line.ProductCode);
            item.SubItems.Add(FormatQuantity(line.Packages));
            item.SubItems.Add(FormatQuantity(line.Multiplier));
            item.SubItems.Add(line.PackageWeightGrams is null
                ? ""
                : FormatWeight(line.PackageWeightGrams.Value * line.Packages));
            if (line.ProductName == "Prodotto non trovato")
                item.BackColor = Color.FromArgb(255, 242, 230);
            _items.Items.Add(item);
        }
        _items.EndUpdate();
    }

    private void ResizeColumns()
    {
        if (_items.Columns.Count == 0)
            return;

        var available = Math.Max(620, _items.ClientSize.Width - 24);
        _items.Columns[0].Width = 150;
        _items.Columns[2].Width = 130;
        _items.Columns[3].Width = 95;
        _items.Columns[4].Width = 110;
        _items.Columns[5].Width = 120;
        _items.Columns[1].Width = Math.Max(250, available - 605);
    }

    private void UpdateStatus(string? message = null)
    {
        _status.Text = message ??
            $"Articoli: {_repository.Data.WebRows.Count} - barcode: {_productsByBarcode.Count} - pesi: {_packageWeightGramsByCode.Count} - righe: {_linesByBarcode.Count}";
    }

    private async Task<Dictionary<string, decimal>> LoadAdmWeightsCachedAsync(UpdateForm progress, bool forceDownload)
    {
        var cached = forceDownload ? [] : TryLoadAdmWeightsCache();
        if (cached.Count > 0)
            return cached;

        progress.Status = "Scarico listini ADM...";
        var downloaded = await LoadAdmWeightsAsync();
        SaveAdmWeightsCache(downloaded);
        return downloaded;
    }

    private static Dictionary<string, decimal> TryLoadAdmWeightsCache()
    {
        try
        {
            if (!File.Exists(AdmWeightsCachePath))
                return [];

            var json = File.ReadAllText(AdmWeightsCachePath);
            return JsonSerializer.Deserialize<Dictionary<string, decimal>>(json, JsonOptions) ?? [];
        }
        catch
        {
            return [];
        }
    }

    private static void SaveAdmWeightsCache(Dictionary<string, decimal> weights)
    {
        Directory.CreateDirectory(CacheFolder);
        File.WriteAllText(AdmWeightsCachePath, JsonSerializer.Serialize(weights, JsonOptions));
    }

    private async Task<Dictionary<string, decimal>> LoadAdmWeightsAsync()
    {
        var result = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < AdmPdfUrls.Length; i++)
        {
            var pdfPath = Path.Combine(Path.GetTempPath(), $"ADM-LISTINO-{i}.pdf");
            await _downloads.DownloadFileAsync(AdmPdfUrls[i], pdfPath);

            using var document = PdfDocument.Open(pdfPath);
            foreach (var page in document.GetPages())
            {
                var pageText = page.Text;
                if (pageText.Contains("1.000 pz", StringComparison.OrdinalIgnoreCase))
                    continue;

                foreach (Match match in AdmLineRegex.Matches(pageText))
                {
                    var code = NormalizeCode(match.Groups["code"].Value);
                    var unit = match.Groups["unit"].Value;
                    if (!TryParseItalianDecimal(match.Groups["amount"].Value, out var amount) ||
                        !TryParseItalianDecimal(match.Groups["kg"].Value, out var pricePerKg) ||
                        !TryParseItalianDecimal(match.Groups["pack"].Value, out var pricePerPack) ||
                        pricePerKg <= 0)
                        continue;

                    var grams = unit.Equals("grammi", StringComparison.OrdinalIgnoreCase)
                        ? amount
                        : pricePerPack / pricePerKg * 1000m;

                    result.TryAdd(code, Math.Round(grams, 2));
                }
            }
        }

        return result;
    }

    private static bool TryParseItalianDecimal(string value, out decimal result) =>
        decimal.TryParse(value.Replace(".", ""), NumberStyles.Number, CultureInfo.GetCultureInfo("it-IT"), out result);

    private static string FormatWeight(decimal grams) =>
        grams >= 1000
            ? $"{grams / 1000m:0.###} kg"
            : $"{grams:0.##} g";

    private static string FormatQuantity(decimal value) =>
        value % 1 == 0 ? value.ToString("0") : value.ToString("0.####");

    private static string NormalizeBarcode(string value) =>
        new(value.Where(char.IsLetterOrDigit).ToArray());

    private static string NormalizeCode(string value) =>
        new(value.Trim().Where(char.IsLetterOrDigit).ToArray());

    private static string Get(string[] row, int index) =>
        index >= 0 && index < row.Length ? row[index] : "";

    private sealed class ScanLine
    {
        public string Barcode { get; set; } = "";
        public string ProductName { get; set; } = "";
        public string ProductCode { get; set; } = "";
        public decimal Packages { get; set; }
        public decimal Multiplier { get; set; } = 1m;
        public decimal? PackageWeightGrams { get; set; }
    }

    private sealed record BarcodeProductInfo(ProductRow Product, decimal Multiplier);
}
