using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class VerificationForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextBox _report = new()
    {
        Multiline = true,
        ReadOnly = true,
        ScrollBars = ScrollBars.Both,
        WordWrap = false
    };

    public VerificationForm(AppRepository repository)
    {
        _repository = repository;

        Text = "Verifica dati";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 900;
        Height = 680;
        MinimumSize = new Size(820, 600);
        AutoScroll = true;

        var refresh = Ui.Button("Aggiorna", 120, 34);
        refresh.SetBounds(18, 16, 120, 34);
        refresh.Click += (_, _) => RefreshReport();

        var clearCache = Ui.Button("Svuota cache", 120, 34);
        clearCache.SetBounds(154, 16, 120, 34);
        clearCache.Click += (_, _) =>
        {
            _repository.Cache.Clear();
            MessageBox.Show(this, "Cache eliminata.", "Cache");
        };

        _report.SetBounds(18, 66, 820, 540);
        _report.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

        Controls.AddRange([refresh, clearCache, _report]);
        RefreshReport();
    }

    private void RefreshReport() => _report.Text = new VerificationService().BuildReport(_repository.Data);
}
