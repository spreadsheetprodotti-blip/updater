using CondivisioneArticoliApp.Models;
using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class ControlForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextNormalizer _normalizer;
    private readonly MatchingService _matcher;
    private readonly ListView _rows = new();
    private readonly ListView _suggestions = new();
    private readonly Label _result = new();
    private readonly TextBox _filter = new();
    private readonly Label _status = Ui.Label("");
    private readonly ComboBox[] _supplierPriority;
    private readonly Panel _workPanel = new();
    private readonly Panel _supplierPanel = new();
    private readonly Panel _header = Ui.Card(22, 18, 1130, 64);
    private readonly Button _back = Ui.Button("Indietro", 105, 34);
    private Label? _title;
    private Label? _hint;
    private readonly Label _searchLabel = Ui.Label("Cerca");
    private readonly Label _rowsLabel = Ui.Label("Righe da controllare", true);
    private readonly Label _suggestionsLabel = Ui.Label("Suggerimenti", true);
    private readonly Label _detailsLabel = Ui.Label("Dettaglio confronto", true);
    private int _currentIndex;

    public ControlForm(AppRepository repository, TextNormalizer normalizer)
    {
        _repository = repository;
        _normalizer = normalizer;
        _matcher = new MatchingService(_normalizer);
        _supplierPriority = Enumerable.Range(0, 5).Select(_ => new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList }).ToArray();

        Text = "Abbina articoli";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 1320;
        Height = 900;
        MinimumSize = new Size(1120, 720);
        AutoScroll = false;

        BuildLayout();
        Resize += (_, _) => ApplyResponsiveLayout();
        LoadData();
        FormClosing += async (_, _) =>
        {
            try
            {
                await _repository.Learning.SendBatchAsync();
            }
            catch
            {
                // Il batch resta in memoria solo per la sessione corrente.
            }
        };
    }

    private void BuildLayout()
    {
        _header.BorderStyle = BorderStyle.None;
        _header.BackColor = Color.FromArgb(232, 240, 249);
        _title = Ui.Label("Abbina articoli", true);
        _title.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
        _title.SetBounds(16, 6, 760, 36);
        _title.AutoSize = false;
        _title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _hint = Ui.Label("Conferma i suggerimenti, salta i casi dubbi ed esporta quando hai finito.");
        _hint.ForeColor = Ui.TextMuted;
        _hint.SetBounds(18, 44, 820, 20);
        _hint.AutoSize = false;
        _hint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _back.Click += (_, _) => Close();
        _header.Controls.AddRange([_title, _hint, _back]);

        _workPanel.BackColor = Ui.Background;
        _workPanel.BorderStyle = BorderStyle.None;

        _searchLabel.SetBounds(0, 4, 45, 22);
        _filter.SetBounds(52, 0, 330, 28);
        Ui.StyleInput(_filter);
        _filter.TextChanged += (_, _) => LoadRows(_filter.Text);

        _status.SetBounds(400, 4, 420, 22);
        _status.AutoSize = false;
        _status.ForeColor = Ui.TextMuted;

        _rowsLabel.SetBounds(0, 46, 220, 22);
        _rows.SetBounds(0, 74, 700, 285);
        _rows.Anchor = AnchorStyles.None;
        _rows.View = View.Details;
        _rows.FullRowSelect = true;
        _rows.HideSelection = false;
        Ui.StyleGrid(_rows);
        _rows.Columns.Add("Stato", 58);
        _rows.Columns.Add("Descrizione", 460);
        _rows.Columns.Add("Scelta", 165);
        _rows.SelectedIndexChanged += (_, _) =>
        {
            if (_rows.SelectedItems.Count == 0)
                return;

            _currentIndex = _rows.SelectedItems[0].Tag is int index ? index : 0;
            LoadCurrentRow();
        };

        _suggestionsLabel.SetBounds(0, 382, 200, 22);
        _suggestions.SetBounds(0, 410, 700, 190);
        _suggestions.Anchor = AnchorStyles.None;
        _suggestions.View = View.Details;
        _suggestions.FullRowSelect = true;
        _suggestions.HideSelection = false;
        Ui.StyleGrid(_suggestions);
        _suggestions.Columns.Add("Prodotto", 460);
        _suggestions.Columns.Add("Fornitore", 215);
        _suggestions.DoubleClick += (_, _) => ConfirmSelection();

        _detailsLabel.SetBounds(0, 622, 200, 22);
        _result.SetBounds(0, 650, 700, 62);
        _result.Anchor = AnchorStyles.None;
        _result.BorderStyle = BorderStyle.FixedSingle;
        _result.BackColor = Color.White;
        _result.Padding = new Padding(8);

        _supplierPanel.SetBounds(770, 156, 370, 560);
        _supplierPanel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _supplierPanel.BackColor = Ui.Surface;
        _supplierPanel.BorderStyle = BorderStyle.FixedSingle;

        var supplierLabel = Ui.Label("Fornitori preferiti", true);
        supplierLabel.SetBounds(18, 18, 260, 22);

        var supplierHint = Ui.Label("Usati per ordinare i suggerimenti.");
        supplierHint.ForeColor = Ui.TextMuted;
        supplierHint.SetBounds(18, 42, 280, 20);
        supplierHint.AutoSize = false;
        _supplierPanel.Controls.AddRange([supplierLabel, supplierHint]);

        for (var i = 0; i < _supplierPriority.Length; i++)
        {
            _supplierPriority[i].SetBounds(18, 78 + i * 44, 330, 30);
            Ui.StyleInput(_supplierPriority[i]);
            _supplierPanel.Controls.Add(_supplierPriority[i]);
        }

        var choose = Ui.Button("Conferma", 96, 38, primary: true);
        choose.SetBounds(18, 450, 110, 42);
        choose.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        choose.Font = new Font(choose.Font, FontStyle.Bold);
        choose.Click += (_, _) => ConfirmSelection();

        var skip = Ui.Button("Salta", 90, 36);
        skip.SetBounds(142, 450, 100, 42);
        skip.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        skip.Click += (_, _) =>
        {
            _currentIndex = Math.Min(_currentIndex + 1, _repository.Data.FileRows.Count - 1);
            SelectCurrentInList();
            LoadCurrentRow();
        };

        var export = Ui.Button("Esporta", 90, 36);
        export.SetBounds(256, 450, 100, 42);
        export.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        export.Click += (_, _) => ExportResults();
        _supplierPanel.Controls.AddRange([choose, skip, export]);
        _workPanel.Controls.AddRange([
            _searchLabel, _filter, _status,
            _rowsLabel, _rows,
            _suggestionsLabel, _suggestions,
            _detailsLabel, _result
        ]);

        Controls.AddRange([
            _header,
            _workPanel,
            _supplierPanel
        ]);

        ApplyResponsiveLayout();
    }

    private void ApplyResponsiveLayout()
    {
        SuspendLayout();

        var contentWidth = Math.Max(ClientSize.Width, MinimumSize.Width);
        var contentHeight = Math.Max(ClientSize.Height, MinimumSize.Height);
        var left = 30;
        var rightMargin = 32;
        var gap = 30;
        var panelWidth = Math.Min(370, Math.Max(330, contentWidth / 4));
        var panelLeft = contentWidth - panelWidth - rightMargin;
        var listWidth = Math.Max(620, panelLeft - left - gap);
        var workTop = 116;
        var bottomMargin = 28;
        var workHeight = Math.Max(520, contentHeight - workTop - bottomMargin);

        _header.SetBounds(22, 18, contentWidth - 54, 76);
        _back.SetBounds(_header.Width - 122, 20, 105, 34);
        _title?.SetBounds(16, 6, Math.Max(220, _back.Left - 28), 36);
        _hint?.SetBounds(18, 44, Math.Max(260, _back.Left - 30), 20);
        _workPanel.SetBounds(left, workTop, listWidth, workHeight);

        _searchLabel.SetBounds(0, 4, 45, 22);
        _filter.SetBounds(52, 0, Math.Min(390, Math.Max(260, listWidth / 3)), 28);
        var statusLeft = _filter.Right + 24;
        _status.SetBounds(statusLeft, 4, Math.Max(220, listWidth - statusLeft), 22);

        _rowsLabel.SetBounds(0, 46, 220, 22);

        var rowsTop = 74;
        var labelGap = 28;
        var sectionGap = 42;
        var resultHeight = Math.Clamp(workHeight / 9, 58, 92);
        var resultTop = workHeight - resultHeight;
        var detailsTop = resultTop - labelGap;
        var availableListsHeight = Math.Max(330, detailsTop - rowsTop - sectionGap);
        var rowsHeight = Math.Max(210, (int)(availableListsHeight * 0.58));
        var suggestionsTop = rowsTop + rowsHeight + sectionGap;
        var suggestionsHeight = Math.Max(130, detailsTop - suggestionsTop - labelGap);

        _rows.SetBounds(0, rowsTop, listWidth, rowsHeight);
        _suggestionsLabel.SetBounds(0, suggestionsTop - 28, 200, 22);
        _suggestions.SetBounds(0, suggestionsTop, listWidth, suggestionsHeight);
        _detailsLabel.SetBounds(0, detailsTop, 200, 22);
        _result.SetBounds(0, resultTop, listWidth, resultHeight);

        var rowsAvailableWidth = Math.Max(520, listWidth - _rows.Columns[0].Width - 22);
        _rows.Columns[1].Width = rowsAvailableWidth / 2;
        _rows.Columns[2].Width = rowsAvailableWidth - _rows.Columns[1].Width;

        var suggestionsAvailableWidth = Math.Max(520, listWidth - 22);
        _suggestions.Columns[0].Width = suggestionsAvailableWidth / 2;
        _suggestions.Columns[1].Width = suggestionsAvailableWidth - _suggestions.Columns[0].Width;

        _supplierPanel.SetBounds(panelLeft, workTop + 6, panelWidth, Math.Max(520, workHeight - 12));

        ResumeLayout();
    }

    private void LoadData()
    {
        _matcher.SetUsedProducts(_repository.Data.FileRows.Select(row => row.SelectedProduct));
        _matcher.BuildIndex(_repository.Data.WebRows);

        foreach (var combo in _supplierPriority)
        {
            combo.Items.Clear();
            combo.Items.Add("");
            foreach (var supplier in _repository.Data.Suppliers.OrderBy(s => s.Name))
                combo.Items.Add(supplier.Name);
        }

        LoadRows("");
        if (_repository.Data.FileRows.Count > 0)
        {
            AutoResolveSafeRows();
            LoadRows(_filter.Text);
            LoadCurrentRow();
        }
        else
            _status.Text = "Carica prima un file da Importazione dati";
    }

    private void LoadRows(string filter)
    {
        _rows.Items.Clear();
        var normalizedFilter = _normalizer.Normalize(filter);

        for (var i = 0; i < _repository.Data.FileRows.Count; i++)
        {
            var row = _repository.Data.FileRows[i];
            if (normalizedFilter.Length > 0 && !_normalizer.Normalize(row.Description).Contains(normalizedFilter))
                continue;

            var item = new ListViewItem(row.SelectedProduct.Length > 0 ? "[OK]" : "[ ]")
            {
                Tag = i
            };
            item.SubItems.Add(row.Description);
            item.SubItems.Add(row.SelectedProduct);
            _rows.Items.Add(item);
        }
    }

    private void LoadCurrentRow()
    {
        if (_currentIndex < 0 || _currentIndex >= _repository.Data.FileRows.Count)
            return;

        AutoResolveSafeRows();
        if (_currentIndex < 0 || _currentIndex >= _repository.Data.FileRows.Count)
            return;

        var row = _repository.Data.FileRows[_currentIndex];
        var learningMatch = _repository.Learning.MatchLearning(_repository.Data, _normalizer, row);
        var best = learningMatch is null
            ? _matcher.FindBest(row.Description, row.Barcode)
            : _repository.Data.WebRows.FirstOrDefault(product => product.Name.Equals(learningMatch, StringComparison.OrdinalIgnoreCase));
        var suggestions = _matcher.FindTop(row.Description, 14);
        foreach (var learningSuggestion in _repository.Learning.Suggestions(_repository.Data, _normalizer, row.Description, 10).AsEnumerable().Reverse())
        {
            var product = _repository.Data.WebRows.FirstOrDefault(p => p.Name.Equals(learningSuggestion, StringComparison.OrdinalIgnoreCase));
            if (product is not null && suggestions.All(s => !s.Name.Equals(product.Name, StringComparison.OrdinalIgnoreCase)))
                suggestions.Insert(0, product);
        }
        if (best is not null && suggestions.All(s => s.Name != best.Name))
            suggestions.Insert(0, best);

        _suggestions.Items.Clear();
        foreach (var suggestion in OrderBySupplierPriority(suggestions))
        {
            var supplier = _repository.Data.Suppliers.FirstOrDefault(s => s.Vat == suggestion.SupplierVat)?.Name ?? "";
            var item = new ListViewItem(suggestion.Name) { Tag = suggestion };
            item.SubItems.Add(supplier);
            _suggestions.Items.Add(item);
        }

        if (_suggestions.Items.Count > 0)
            _suggestions.Items[0].Selected = true;

        _result.Text = best is null
            ? row.Description
            : $"{row.Description}{Environment.NewLine}{best.Name}";

        _status.Text = $"Riga {_currentIndex + 1} di {_repository.Data.FileRows.Count}";
        SelectCurrentInList();
    }

    private void AutoResolveSafeRows()
    {
        var autoCount = 0;
        while (_currentIndex >= 0 && _currentIndex < _repository.Data.FileRows.Count && autoCount < 20)
        {
            var row = _repository.Data.FileRows[_currentIndex];
            if (!string.IsNullOrWhiteSpace(row.SelectedProduct))
                break;

            var resolved = TryResolveByLearningCode(row) ?? TryResolveBySafeSupplierMatch(row);
            if (resolved is null)
                break;

            row.SelectedProduct = resolved.Name;
            _matcher.SetUsedProducts(_repository.Data.FileRows.Select(r => r.SelectedProduct));
            _currentIndex++;
            autoCount++;
        }

        if (autoCount > 0)
            _repository.SaveCache();
    }

    private ProductRow? TryResolveByLearningCode(ArticleRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Code))
            return null;

        return _repository.Data.LearningByCode.TryGetValue(row.Code, out var productName)
            ? _repository.Data.WebRows.FirstOrDefault(product => product.Name.Equals(productName, StringComparison.OrdinalIgnoreCase))
            : null;
    }

    private ProductRow? TryResolveBySafeSupplierMatch(ArticleRow row)
    {
        var match = _matcher.FindBest(row.Description, row.Barcode);
        if (match is null)
            return null;
        if (string.IsNullOrWhiteSpace(row.SupplierVat) || string.IsNullOrWhiteSpace(match.SupplierVat))
            return null;
        if (!row.SupplierVat.Equals(match.SupplierVat, StringComparison.OrdinalIgnoreCase))
            return null;
        if (!MatchingService.IsSafeMatch(_normalizer, row.Description, match.Name))
            return null;

        return match;
    }

    private IEnumerable<ProductRow> OrderBySupplierPriority(IEnumerable<ProductRow> products)
    {
        var priorities = _supplierPriority
            .Select((combo, index) => new { Name = combo.Text, Index = index + 1 })
            .Where(x => !string.IsNullOrWhiteSpace(x.Name))
            .ToDictionary(x => x.Name, x => x.Index, StringComparer.OrdinalIgnoreCase);

        return products.OrderBy(product =>
        {
            var supplier = _repository.Data.Suppliers.FirstOrDefault(s => s.Vat == product.SupplierVat)?.Name ?? "";
            return priorities.TryGetValue(supplier, out var priority) ? priority : 99;
        });
    }

    private void ConfirmSelection()
    {
        if (_currentIndex < 0 || _currentIndex >= _repository.Data.FileRows.Count)
            return;
        if (_suggestions.SelectedItems.Count == 0)
            return;

        if (_suggestions.SelectedItems[0].Tag is not ProductRow product)
            return;

        var row = _repository.Data.FileRows[_currentIndex];
        row.SelectedProduct = product.Name;
        _repository.Learning.QueueLearning(_repository.Data, _normalizer, row, product);
        _matcher.SetUsedProducts(_repository.Data.FileRows.Select(r => r.SelectedProduct));
        _repository.SaveCache();

        LoadRows(_filter.Text);
        _currentIndex = Math.Min(_currentIndex + 1, _repository.Data.FileRows.Count - 1);
        SelectCurrentInList();
        LoadCurrentRow();
    }

    private void SelectCurrentInList()
    {
        foreach (ListViewItem item in _rows.Items)
        {
            if (item.Tag is int index && index == _currentIndex)
            {
                item.Selected = true;
                item.EnsureVisible();
                break;
            }
        }
    }

    private async void ExportResults()
    {
        using var firstDialog = new SaveFileDialog
        {
            Filter = "File Excel|*.xlsx",
            FileName = "PRIMA PARTE.xlsx",
            Title = "Salva PRIMA PARTE"
        };

        if (firstDialog.ShowDialog(this) != DialogResult.OK)
            return;

        using var secondDialog = new SaveFileDialog
        {
            Filter = "File Excel|*.xlsx",
            FileName = "SECONDA PARTE.xlsx",
            Title = "Salva SECONDA PARTE"
        };

        if (secondDialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            await _repository.Learning.SendBatchAsync();
            _repository.SaveTwoPartResults(firstDialog.FileName, secondDialog.FileName);
            MessageBox.Show(this, "Export completato.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
