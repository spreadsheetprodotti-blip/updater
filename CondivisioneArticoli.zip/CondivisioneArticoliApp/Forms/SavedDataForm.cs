using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class SavedDataForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextNormalizer _normalizer;
    private readonly Label _summary = Ui.Label("");

    public SavedDataForm(AppRepository repository, TextNormalizer normalizer)
    {
        _repository = repository;
        _normalizer = normalizer;

        Text = "Dati salvati";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 620;
        Height = 410;
        MinimumSize = new Size(560, 360);

        var title = Ui.Label("Cambia i dati salvati", true);
        title.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
        title.SetBounds(28, 24, 520, 32);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        _summary.SetBounds(30, 66, 530, 74);
        _summary.AutoSize = false;
        _summary.ForeColor = Ui.TextMuted;
        _summary.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        var loadFile = Ui.Button("Sostituisci file articoli", 230, 42, primary: true);
        loadFile.SetBounds(30, 160, 230, 42);
        loadFile.Click += (_, _) => LoadFile();

        var refreshOnline = Ui.Button("Aggiorna dati online", 230, 42);
        refreshOnline.SetBounds(292, 160, 230, 42);
        refreshOnline.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        refreshOnline.Click += async (_, _) => await RefreshOnlineAsync();

        var clear = Ui.Button("Svuota dati salvati", 230, 42);
        clear.SetBounds(30, 220, 230, 42);
        clear.Click += (_, _) => ClearSavedData();

        var openFolder = Ui.Button("Apri cartella dati", 230, 42);
        openFolder.SetBounds(292, 220, 230, 42);
        openFolder.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        openFolder.Click += (_, _) =>
        {
            Directory.CreateDirectory(_repository.Cache.CacheFolder);
            System.Diagnostics.Process.Start("explorer.exe", _repository.Cache.CacheFolder);
        };

        var verify = Ui.Button("Verifica contenuto", 230, 42);
        verify.SetBounds(30, 280, 230, 42);
        verify.Click += (_, _) => new VerificationForm(_repository).ShowDialog(this);

        Controls.AddRange([title, _summary, loadFile, refreshOnline, clear, openFolder, verify]);
        RefreshSummary();
    }

    private void RefreshSummary()
    {
        _summary.Text =
            $"File articoli: {_repository.Data.FileRows.Count} righe{Environment.NewLine}" +
            $"Catalogo online: {_repository.Data.WebRows.Count} articoli, fornitori: {_repository.Data.Suppliers.Count}{Environment.NewLine}" +
            $"Categorie: {_repository.Data.Categories.Count}, barcode: {_repository.Data.Barcodes.Count}, learning: {_repository.Data.LearningItems.Count}";
    }

    private void LoadFile()
    {
        using var dialog = new OpenFileDialog
        {
            Filter = "File Excel|*.xlsx;*.xlsm;*.xls",
            Title = "Seleziona il nuovo file articoli"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            _repository.LoadFile(dialog.FileName);
            RefreshSummary();
            MessageBox.Show(this, "File articoli aggiornato nei dati salvati.", "Dati salvati");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore file", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task RefreshOnlineAsync()
    {
        try
        {
            using var progress = new UpdateForm("Aggiornamento dati online...");
            progress.Show(this);
            progress.Refresh();
            var reporter = new Progress<string>(message => progress.Status = message);
            await _repository.DownloadFullInventoryAsync(reporter);
            await _repository.LoadRemoteLookupsAsync(_normalizer, reporter);
            progress.Close();

            RefreshSummary();
            MessageBox.Show(this, "Dati online aggiornati.", "Dati salvati");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore aggiornamento", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ClearSavedData()
    {
        var answer = MessageBox.Show(this,
            "Vuoi eliminare i dati salvati su questo PC?",
            "Svuota dati salvati",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (answer != DialogResult.Yes)
            return;

        _repository.ClearSavedData();
        RefreshSummary();
        MessageBox.Show(this, "Dati salvati eliminati.", "Dati salvati");
    }
}
