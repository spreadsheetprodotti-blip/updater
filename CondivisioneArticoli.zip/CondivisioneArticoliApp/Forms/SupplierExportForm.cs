using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class SupplierExportForm : Form
{
    private readonly AppRepository _repository;
    private readonly CheckedListBox _suppliers = new();
    private readonly TextBox _filter = new();
    private readonly Label _count = Ui.Label("Selezionati: 0", true);

    public SupplierExportForm(AppRepository repository)
    {
        _repository = repository;

        Text = "Seleziona fornitori";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 860;
        Height = 620;
        MinimumSize = new Size(800, 560);
        AutoScroll = true;

        BuildLayout();
        LoadSuppliers("");
    }

    private void BuildLayout()
    {
        _suppliers.SetBounds(24, 24, 520, 390);
        _suppliers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        _suppliers.CheckOnClick = true;
        _suppliers.DisplayMember = "Name";
        _suppliers.ItemCheck += (_, _) => BeginInvoke((Action)UpdateCount);

        _filter.SetBounds(580, 24, 220, 28);
        _filter.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _filter.TextChanged += (_, _) => LoadSuppliers(_filter.Text);

        var clearFilter = Ui.Button("Annulla filtro", 135, 34);
        clearFilter.SetBounds(580, 72, 150, 38);
        clearFilter.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        clearFilter.Click += (_, _) => _filter.Clear();

        _count.SetBounds(580, 132, 200, 26);
        _count.Anchor = AnchorStyles.Top | AnchorStyles.Right;

        var export = Ui.Button("Esporta articoli", 210, 40);
        export.SetBounds(24, 452, 240, 46);
        export.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        export.Font = new Font(export.Font, FontStyle.Bold);
        export.Click += (_, _) => ExportSelected();

        var reset = Ui.Button("Svuota selezione", 170, 40);
        reset.SetBounds(570, 452, 190, 46);
        reset.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        reset.Click += (_, _) =>
        {
            for (var i = 0; i < _suppliers.Items.Count; i++)
                _suppliers.SetItemChecked(i, false);
            UpdateCount();
        };

        var back = Ui.Button("Indietro", 120, 36);
        back.SetBounds(302, 458, 120, 40);
        back.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        back.Click += (_, _) => Close();

        Controls.AddRange([_suppliers, _filter, clearFilter, _count, export, back, reset]);
    }

    private void LoadSuppliers(string filter)
    {
        var selectedVats = CheckedSupplierVats().ToHashSet(StringComparer.OrdinalIgnoreCase);
        _suppliers.Items.Clear();

        foreach (var supplier in _repository.Data.Suppliers.OrderBy(s => s.Name))
        {
            if (!string.IsNullOrWhiteSpace(filter) &&
                !supplier.Name.Contains(filter, StringComparison.OrdinalIgnoreCase))
                continue;

            var index = _suppliers.Items.Add(supplier);
            _suppliers.SetItemChecked(index, selectedVats.Contains(supplier.Vat));
        }

        UpdateCount();
    }

    private IEnumerable<string> CheckedSupplierVats()
    {
        foreach (var item in _suppliers.CheckedItems)
        {
            if (item is Models.SupplierRow supplier)
                yield return supplier.Vat;
        }
    }

    private void UpdateCount() => _count.Text = $"Selezionati: {_suppliers.CheckedItems.Count}";

    private void ExportSelected()
    {
        var selected = CheckedSupplierVats().ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (selected.Count == 0)
        {
            MessageBox.Show(this, "Nessun fornitore selezionato.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        using var dialog = new FolderBrowserDialog
        {
            Description = "Seleziona cartella export"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        try
        {
            _repository.SaveSupplierExportFolder(dialog.SelectedPath, selected);
            MessageBox.Show(this, "Export completato.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore export", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
