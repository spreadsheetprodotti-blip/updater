using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class MainForm : Form
{
    private readonly AppRepository _repository = new();
    private readonly TextNormalizer _normalizer = new();
    private readonly Label _status = Ui.Label("");
    private readonly Label _title = Ui.Label("Condivisione articoli", true);
    private readonly Label _subtitle = Ui.Label("Scegli il flusso da avviare.");
    private readonly Panel _tobaccoSection = Ui.Card(28, 112, 480, 176);
    private readonly Panel _federationSection = Ui.Card(528, 112, 360, 176);

    public MainForm()
    {
        Text = "Condivisione articoli";
        StartPosition = FormStartPosition.CenterScreen;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 1080;
        Height = 570;
        MinimumSize = new Size(920, 500);

        _title.Font = new Font("Segoe UI", 21F, FontStyle.Bold);
        _title.SetBounds(30, 24, 720, 46);
        _title.AutoSize = false;
        _title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        _subtitle.ForeColor = Ui.TextMuted;
        _subtitle.SetBounds(32, 72, 620, 24);
        _subtitle.AutoSize = false;
        _subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        BuildTobaccoSection();
        BuildFederationSection();

        _status.SetBounds(32, 460, 850, 24);
        _status.AutoSize = false;
        _status.ForeColor = Ui.TextMuted;
        _status.TextAlign = ContentAlignment.MiddleRight;
        _status.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

        Controls.AddRange([_title, _subtitle, _tobaccoSection, _federationSection, _status]);
        Resize += (_, _) => ApplyLayout();
        ApplyLayout();

        if (_repository.TryLoadCache())
            _status.Text = "Dati salvati caricati";
    }

    private void BuildTobaccoSection()
    {
        var title = Ui.Label("Tabaccherie", true);
        title.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        title.SetBounds(20, 18, 420, 30);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        AddSectionAction(_tobaccoSection, 72, "Per le tabaccherie", (_, _) =>
            ShowChild(new TobaccoForm(_repository, _normalizer)));

        AddSectionAction(_tobaccoSection, 132, "Per cambiare i dati salvati", async (_, _) =>
            await OpenSavedDataControlAsync());

        AddSectionAction(_tobaccoSection, 192, "Spunta ordine", (_, _) =>
            ShowChild(new OrderCheckForm(_repository)));

        AddSectionAction(_tobaccoSection, 252, "Azzeramento inventario", (_, _) =>
            ShowChild(new InventoryResetForm()));

        _tobaccoSection.Controls.Add(title);
    }

    private void BuildFederationSection()
    {
        var title = Ui.Label("Federazione tabaccai", true);
        title.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        title.SetBounds(20, 18, 320, 30);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        AddSectionAction(_federationSection, 92, "Per installare i database", (_, _) =>
            ShowChild(new ExportForm(_repository)));

        _federationSection.Controls.Add(title);
    }

    private static void AddSectionAction(Control parent, int top, string labelText, EventHandler action)
    {
        var label = Ui.Label(labelText, true);
        label.SetBounds(22, top + 2, parent.Width - 150, 42);
        label.AutoSize = false;
        label.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        label.TextAlign = ContentAlignment.MiddleLeft;

        var button = Ui.Button("Inizia", 104, 40, primary: true);
        button.SetBounds(parent.Width - 126, top, 104, 40);
        button.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        button.Click += action;

        parent.Controls.AddRange([label, button]);
    }

    private void ApplyLayout()
    {
        var gap = 20;
        var margin = 28;
        var available = Math.Max(840, ClientSize.Width - margin * 2 - gap);
        var federationWidth = Math.Max(390, (int)(available * 0.42));
        var tobaccoWidth = available - federationWidth;

        _tobaccoSection.SetBounds(margin, 124, tobaccoWidth, 340);
        _federationSection.SetBounds(_tobaccoSection.Right + gap, 124, federationWidth, 220);
        _title.SetBounds(30, 24, ClientSize.Width - 60, 46);
        _subtitle.SetBounds(32, 72, ClientSize.Width - 64, 24);
        _status.SetBounds(32, ClientSize.Height - 62, ClientSize.Width - 70, 24);
    }

    private void ShowChild(Form child)
    {
        Hide();
        try
        {
            child.ShowDialog();
        }
        finally
        {
            Show();
            Activate();
        }
    }

    private async Task OpenSavedDataControlAsync()
    {
        try
        {
            var answer = MessageBox.Show(this,
                "Vuoi caricare un nuovo file?",
                "Controllo articoli",
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question);

            if (answer == DialogResult.Cancel)
                return;

            if (answer == DialogResult.Yes)
            {
                using var dialog = new OpenFileDialog
                {
                    Filter = "File Excel|*.xlsx;*.xlsm;*.xls",
                    Title = "Seleziona file da caricare"
                };

                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;

                _repository.LoadFile(dialog.FileName);
            }

            if (_repository.Data.FileRows.Count == 0)
            {
                MessageBox.Show(this, "Non ci sono dati FILE salvati da controllare.", "Controllo articoli", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var progress = new UpdateForm("Caricamento dati online...");
            progress.Show(this);
            progress.Refresh();

            var reporter = new Progress<string>(message => progress.Status = message);
            await _repository.DownloadFullInventoryAsync(reporter);
            await _repository.LoadRemoteLookupsAsync(_normalizer, reporter);
            progress.Close();

            ShowChild(new ControlForm(_repository, _normalizer));
            _status.Text = $"FILE: {_repository.Data.FileRows.Count} righe, WEB: {_repository.Data.WebRows.Count} articoli";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore controllo articoli", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
