namespace CondivisioneArticoliApp.Forms;

internal static class Ui
{
    public static readonly Font DefaultFont = new("Segoe UI", 9.5F);
    public static readonly Color Background = Color.FromArgb(244, 247, 250);
    public static readonly Color Surface = Color.White;
    public static readonly Color Border = Color.FromArgb(216, 222, 230);
    public static readonly Color Primary = Color.FromArgb(24, 92, 165);
    public static readonly Color PrimarySoft = Color.FromArgb(230, 240, 252);
    public static readonly Color TextMuted = Color.FromArgb(92, 101, 112);

    public static Button Button(string text, int width = 130, int height = 34, bool primary = false)
    {
        return new Button
        {
            Text = text,
            Width = width,
            Height = height,
            Font = DefaultFont,
            FlatStyle = FlatStyle.Flat,
            BackColor = primary ? Primary : Surface,
            ForeColor = primary ? Color.White : Color.FromArgb(35, 42, 50),
            Cursor = Cursors.Hand,
            UseVisualStyleBackColor = false
        };
    }

    public static Label Label(string text, bool bold = false)
    {
        return new Label
        {
            Text = text,
            AutoSize = true,
            Font = bold ? new Font(DefaultFont, FontStyle.Bold) : DefaultFont
        };
    }

    public static Panel Card(int left, int top, int width, int height)
    {
        return new Panel
        {
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            BackColor = Surface,
            BorderStyle = BorderStyle.FixedSingle
        };
    }

    public static void StyleGrid(ListView view)
    {
        view.BorderStyle = BorderStyle.FixedSingle;
        view.BackColor = Surface;
        view.GridLines = true;
        view.Font = DefaultFont;
    }

    public static void StyleInput(Control control)
    {
        control.Font = DefaultFont;
        control.BackColor = Surface;
    }
}
