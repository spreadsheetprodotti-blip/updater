using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class LinkForm : Form
{
    private readonly TextBox _input = new() { Multiline = true, ScrollBars = ScrollBars.Vertical };
    private readonly TextBox _output = new() { Multiline = true, ScrollBars = ScrollBars.Vertical, ReadOnly = true };

    public LinkForm()
    {
        Text = "Conversione link GitHub";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 680;
        Height = 420;
        MinimumSize = new Size(640, 390);
        AutoScroll = true;

        var header = Ui.Card(24, 24, 590, 68);
        header.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.BorderStyle = BorderStyle.None;
        header.BackColor = Color.FromArgb(232, 240, 249);
        var title = Ui.Label("Conversione link GitHub", true);
        title.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        title.SetBounds(16, 10, 520, 28);
        title.AutoSize = false;
        title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        var subtitle = Ui.Label("Trasforma un link GitHub nel formato raw.");
        subtitle.ForeColor = Ui.TextMuted;
        subtitle.SetBounds(18, 38, 520, 20);
        subtitle.AutoSize = false;
        subtitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        header.Controls.AddRange([title, subtitle]);

        _input.SetBounds(24, 120, 590, 70);
        _output.SetBounds(24, 280, 590, 74);
        Ui.StyleInput(_input);
        Ui.StyleInput(_output);

        var convert = Ui.Button("Converti", primary: true);
        convert.SetBounds(24, 214, 150, 40);
        convert.Click += (_, _) => _output.Text = Services.LinkConverter.ConvertToRaw(_input.Text);

        var copy = Ui.Button("Copia");
        copy.SetBounds(464, 214, 150, 40);
        copy.Click += (_, _) =>
        {
            if (!string.IsNullOrWhiteSpace(_output.Text))
                Clipboard.SetText(_output.Text);
        };

        Controls.AddRange([header, _input, convert, copy, _output]);
    }
}
