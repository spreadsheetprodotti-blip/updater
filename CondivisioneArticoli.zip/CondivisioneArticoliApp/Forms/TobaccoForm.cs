using CondivisioneArticoliApp.Services;

namespace CondivisioneArticoliApp.Forms;

public sealed class TobaccoForm : Form
{
    private readonly AppRepository _repository;
    private readonly TextNormalizer _normalizer;
    private readonly Label _status = Ui.Label("");

    public TobaccoForm(AppRepository repository, TextNormalizer normalizer)
    {
        _repository = repository;
        _normalizer = normalizer;

        Text = "Importazione dati";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Color.FromArgb(240, 240, 240);
        Width = 505;
        Height = 370;
        MinimumSize = new Size(505, 370);

        var importWeb = Ui.Button("Importa da Web", 135, 46);
        importWeb.Left = 42;
        importWeb.Top = 42;
        importWeb.Click += async (_, _) => await ImportFromWebAsync();

        var exportData = Ui.Button("Esporta i dati", 135, 46);
        exportData.Left = 244;
        exportData.Top = 42;
        exportData.Click += (_, _) => ShowChild(new ExportForm(_repository));

        var importFile = Ui.Button("Importa da File", 135, 46);
        importFile.Left = 42;
        importFile.Top = 112;
        importFile.Click += (_, _) => ImportFromFile();

        var compare = Ui.Button("Compara i Dati", 135, 46);
        compare.Left = 42;
        compare.Top = 182;
        compare.Click += async (_, _) => await CompareDataAsync();

        var back = Ui.Button("Indietro", 105, 36);
        back.Left = 42;
        back.Top = 254;
        back.Click += (_, _) => Close();

        _status.Left = 205;
        _status.Top = 260;
        _status.Width = 240;
        _status.Height = 22;
        _status.AutoSize = false;
        _status.ForeColor = Ui.TextMuted;
        _status.TextAlign = ContentAlignment.MiddleRight;

        Controls.AddRange([importWeb, exportData, importFile, compare, back, _status]);
    }

    private async Task ImportFromWebAsync()
    {
        try
        {
            using var progress = new UpdateForm("Importazione dati online...");
            progress.Show(this);
            progress.Refresh();

            var reporter = new Progress<string>(message => progress.Status = message);
            await _repository.DownloadFullInventoryAsync(reporter);
            await _repository.LoadRemoteLookupsAsync(_normalizer, reporter);
            progress.Close();

            _status.Text = $"WEB: {_repository.Data.WebRows.Count} articoli";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore importazione web", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ImportFromFile()
    {
        try
        {
            using var dialog = new OpenFileDialog
            {
                Filter = "File Excel|*.xlsx;*.xlsm;*.xls",
                Title = "Seleziona file da caricare"
            };

            if (dialog.ShowDialog(this) != DialogResult.OK)
                return;

            _repository.LoadFile(dialog.FileName);
            _status.Text = $"FILE: {_repository.Data.FileRows.Count} righe";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore importazione file", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task CompareDataAsync()
    {
        try
        {
            if (_repository.Data.FileRows.Count == 0)
            {
                MessageBox.Show(this, "Importa prima un file articoli.", "Compara i Dati", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (_repository.Data.WebRows.Count == 0)
                await ImportFromWebAsync();

            if (_repository.Data.WebRows.Count == 0)
                return;

            ShowChild(new ControlForm(_repository, _normalizer));
            _status.Text = $"FILE: {_repository.Data.FileRows.Count} righe, WEB: {_repository.Data.WebRows.Count} articoli";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Errore comparazione dati", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ShowChild(Form child)
    {
        Hide();
        try
        {
            child.ShowDialog();
        }
        finally
        {
            Show();
            Activate();
        }
    }
}
