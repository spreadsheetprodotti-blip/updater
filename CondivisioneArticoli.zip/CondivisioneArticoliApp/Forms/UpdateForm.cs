namespace CondivisioneArticoliApp.Forms;

public sealed class UpdateForm : Form
{
    private readonly Label _label = Ui.Label("", true);

    public string Status
    {
        get => _label.Text;
        set => _label.Text = value;
    }

    public UpdateForm(string status)
    {
        Text = "Aggiornamento";
        StartPosition = FormStartPosition.CenterParent;
        Font = Ui.DefaultFont;
        BackColor = Ui.Background;
        Width = 520;
        Height = 210;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        ControlBox = false;

        _label.Text = status;
        _label.TextAlign = ContentAlignment.MiddleCenter;
        _label.BorderStyle = BorderStyle.FixedSingle;
        _label.BackColor = Color.White;
        _label.SetBounds(32, 48, 430, 58);

        Controls.Add(_label);
    }
}
