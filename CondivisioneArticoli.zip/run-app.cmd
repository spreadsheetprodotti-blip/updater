@echo off
setlocal
cd /d "%~dp0CondivisioneArticoliApp"

if exist "C:\Program Files (x86)\dotnet\dotnet.exe" (
  "C:\Program Files (x86)\dotnet\dotnet.exe" run
  exit /b %ERRORLEVEL%
)

if exist "C:\Program Files\dotnet\dotnet.exe" (
  "C:\Program Files\dotnet\dotnet.exe" run
  exit /b %ERRORLEVEL%
)

echo dotnet non trovato. Installa il .NET SDK.
pause
exit /b 1
