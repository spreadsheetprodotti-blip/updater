Option Explicit

Dim shell, fso, basePath, exePath, dotnetPath, projectPath, command

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

basePath = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = basePath & "\build-order-check-quantity\CondivisioneArticoliApp.exe"
projectPath = basePath & "\CondivisioneArticoliApp\CondivisioneArticoliApp.csproj"

If fso.FileExists(exePath) Then
    shell.Run """" & exePath & """", 1, False
Else
    dotnetPath = "C:\Program Files (x86)\dotnet\dotnet.exe"
    If Not fso.FileExists(dotnetPath) Then
        dotnetPath = "C:\Program Files\dotnet\dotnet.exe"
    End If

    If fso.FileExists(dotnetPath) Then
        command = """" & dotnetPath & """ run --project """ & projectPath & """"
        shell.Run command, 0, False
    Else
        MsgBox "dotnet non trovato. Installa il .NET SDK.", vbCritical, "CondivisioneArticoli"
    End If
End If
