# CondivisioneArticoliApp

Questa cartella contiene una prima migrazione C# WinForms del progetto VBA.

## Requisiti

- .NET SDK 8 o Visual Studio con workload ".NET desktop development"

Sul PC attuale risulta installato il runtime .NET, ma non l'SDK. Per compilare da terminale serve installare l'SDK.

## Avvio

```powershell
cd .\csharp\CondivisioneArticoliApp
dotnet restore
dotnet run
```

## Stato della migrazione

Portato:

- maschere principali in WinForms code-first;
- import file Excel;
- download catalogo articoli, fornitori, categorie e barcode;
- conversione link GitHub raw;
- abbreviazioni remote da Google Sheets;
- learning remoto da Google Sheets;
- matching per learning, codice, barcode, parole, prefissi, sinonimi e numeri normalizzati;
- invio batch learning/barcode verso Google Apps Script;
- selezione suggerimento e export risultato;
- export PRIMA PARTE / SECONDA PARTE;
- selezione fornitori per export filtrato;
- export fornitori, inventario, categorie padre/figlio e barcode in cartella.
- cache locale in `%LOCALAPPDATA%\CondivisioneArticoliApp`;
- verifica dati pre-export con conteggi, duplicati e selezioni senza codice WEB;
- controllo aggiornamenti basato sul file `versione.txt`.

Ancora da completare rispetto al VBA:

- rifinitura fine dell'algoritmo per ottenere gli stessi identici punteggi del VBA;
- validazione con file reali e confronto output riga per riga;
- installazione/sostituzione automatica dell'eseguibile dopo il download dell'update.
